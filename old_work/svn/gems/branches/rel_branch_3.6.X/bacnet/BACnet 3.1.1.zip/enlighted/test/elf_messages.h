#ifndef __ELF_MESSAGES_H__
#define __ELF_MESSAGES_H__

#include "elf_common.h"

typedef enum {
    REQ_CMD = 1,
    RSP_CMD
} eMessage_types_t;

typedef struct message_header {
    uint8_t   type;
    uint8_t   ver;
    uint16_t  len;
    uint32_t  txid;   
    uint8_t   cmd;
    union {
        uint8_t   result;
        uint8_t   flags;
    } u;
    uint16_t  rsvd;
} __attribute__ ((__packed__)) message_hdr_t;

typedef struct request_message {
    message_hdr_t   hdr;
    uint8_t         data[];
} __attribute__ ((__packed__)) req_message_t;

typedef struct response_message {
    message_hdr_t   hdr;
    uint8_t         data[];
} __attribute__ ((__packed__)) rsp_message_t;

typedef enum {
    DISCOVER_SENSOR = 1,
    GET_SENSOR_DATA
} eMesssages_t;

typedef struct {
    uint32_t      id;
    NODE_ADDRESS  address;
    uint8_t       state;
} __attribute__ ((__packed__)) gems_device_t;

typedef struct {
    message_hdr_t hdr;
} __attribute__ ((__packed__)) discover_msg_req_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[];
} __attribute__ ((__packed__)) discover_msg_rsp_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       address[];
} __attribute__ ((__packed__)) get_sensor_msg_req_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint32_t      id[]; // variable list
} __attribute__ ((__packed__)) get_sensor_by_id_msg_req_t;

typedef struct {
    uint8_t       result;
    uint32_t      id;
    NODE_ADDRESS  address;
    uint8_t       state;
    uint8_t       version[16];
    uint8_t       light_status;
    uint16_t      load;
    uint8_t       occupancy;
    uint16_t      dim;
} __attribute__ ((__packed__)) sensor_data_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[];
} __attribute__ ((__packed__)) get_sensor_msg_rsp_t;

typedef struct {
    union {
        uint32_t id;
        NODE_ADDRESS address;
    } u;
    uint8_t type;
    uint16_t value;
} __attribute__ ((__packed__)) set_sensor_dim_req_t;

typedef struct {
    uint8_t result;
    union {
        uint32_t id;
        NODE_ADDRESS address;
    } u;
} __attribute__ ((__packed__)) set_sensor_dim_rsp_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to set_sensor_dim_req_t
} __attribute__ ((__packed__)) set_sensor_dim_msg_req_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to set_sensor_dim_rsp_t
} __attribute__ ((__packed__)) set_sensor_dim_msg_rsp_t;

/* GEMS messages start from here */
typedef struct {
    message_hdr_t hdr;
} __attribute__ ((__packed__)) get_gems_data_msg_req_t;

typedef struct {
    message_hdr_t hdr;
    uint8_t       version[16];
} __attribute__ ((__packed__)) get_gems_data_msg_rsp_t;

#endif /* __ELF_MESSAGES_H__ */
