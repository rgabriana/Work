#include "elf_std.h"
#include "elf.h"
#include "elf_gems_api.h"

extern elf_config_t elf_bacnet_config;
const char *elf_get_bi_name(uint32_t object_instance, char *name)
{
    if (!is_object_instance_valid(object_instance, OBJECT_BINARY_INPUT)) {
        return "unknown";
    }
    return elf_get_object_name(OBJECT_BINARY_INPUT, object_instance, name);
}

const char *elf_get_bi_description(uint32_t object_instance)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;
    int8_t            rc = -1;

    if (!is_object_instance_valid(object_instance, OBJECT_BINARY_INPUT)) {
        return "unknown";
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_BINARY_INPUT,
    		object_instance,
			// cr00002 not used, taking out for now -- NULL,
			&index);
    if (rc < 0) {
        return "Unknown";
    }

    ptr = elf_get_object_by_type(OBJECT_BINARY_INPUT, index, OBJECT_CFG_INDEX);
    if (ptr) {
        return ptr->description;
    }

    return "Unknown";
}

BACNET_BINARY_PV elf_get_bi_present_value(uint32_t object_instance)
{
    int       rc = 0;
    uint16_t  index = 0;
    // cr00002 - uint8_t   device_type = 0;

    if (!is_object_instance_valid(object_instance, OBJECT_BINARY_INPUT)) {
        return BINARY_INACTIVE;
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_BINARY_INPUT,
    		object_instance,
			// cr00002 not used, taking out for now -- &device_type,
			&index);
    if (rc < 0) {
        return BINARY_INACTIVE;
    }

    uint8_t occupancy = 0;

    s_zone_t *zptr;
    uint32_t id = elf_get_device_id();
    uint8_t  ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   OBJECT_BINARY_INPUT);
    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            zptr = (s_zone_t *)get_zone_data(id);
            if (!zptr) {
                return BINARY_INACTIVE;
            }
#ifdef EM
            occupancy = zptr->occupancy;
#endif
            free(zptr);
        }
    }
#ifdef EM
    // todo - clarifiy modes
    else if (elf_bacnet_config.mode == SENSORS_ONLY_MODE)
    {
        s_sensor_t *sptr = (s_sensor_t *)get_sensor_data(id, object_instance);
        if (!sptr) {
            return BINARY_INACTIVE;
        }
        occupancy = sptr->occupancy;
    }
    else if ((elf_bacnet_config.mode == ZONE_SENSORS_MODE) ||
             (elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE))
    {
        if (index < ltg_zone_obj_count)
        {
            zptr = (s_zone_t *)get_zone_data(id);
            if (!zptr) {
                return BINARY_INACTIVE;
            }
            occupancy = zptr->occupancy;
            free(zptr);
        }
        else
        {
            if (elf_bacnet_config.mode == ZONE_SENSORS_MODE)
            {
                s_sensor_t *sptr = (s_sensor_t *)get_sensor_data(id, object_instance);
                if (!sptr) {
                    return BINARY_INACTIVE;
                }
                occupancy = sptr->occupancy;
            }
            else {
                return BINARY_INACTIVE;
            }
        }
    }
#endif

    // todo - remove occupancy
    switch (index)
    {
        case ELF_BI_ZONE_OCCUPANCY_OBJECT:
        case ELF_BI_OCCUPANCY_OBJECT:
        {
            return occupancy;
        }
    }
    return BINARY_INACTIVE;
}

