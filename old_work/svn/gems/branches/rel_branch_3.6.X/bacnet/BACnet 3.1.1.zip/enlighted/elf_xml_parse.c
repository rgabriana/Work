#include "elf_xml_parse.h"

int parse_xml(xml_parse_ctx_t *x)
{
	node_t **ans;
	int max;
	int j;

	x->root = roxml_load_buf(x->xml_buf);

	ans = roxml_xpath(x->root, x->xml_xpath, &max);

	x->num_results = max;

	x->results = (char **)malloc(x->num_results*sizeof(char *));

	for (j=0;j<max;j++)
	{
		x->results[j] = NULL;
		node_t *child;
		x->results[j] = roxml_get_content(ans[j], NULL, 0, NULL);
		if (x->results[j])
		{
			if (*(x->results[j]) == 0)
			{
				int i=0;
				int nb_chld = roxml_get_chld_nb(ans[j]);
				for (i=0;i<nb_chld;i++)
				{
					child = roxml_get_chld(ans[j], NULL, i);
					x->results[j] = roxml_get_name(child, NULL, 0);
					//printf("--%s\n", x->results[j]);
				}
			}
			else
			{
				//printf("%s\n", x->results[j]);
			}		
		}
	}
	
	return 0;
}

