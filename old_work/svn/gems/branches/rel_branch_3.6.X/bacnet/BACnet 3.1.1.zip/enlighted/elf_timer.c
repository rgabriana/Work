#include "elf.h"
#include "elf_std.h"

static time_t update_time;

#ifdef EM
static time_t update_area_time;
#endif

// todo - this is a good place to split the configuration/data refresh timers...

void elf_update_timer_init(void)
{
    update_time = time(NULL);
#ifdef EM
    update_area_time = time(NULL);
#endif
    }

void elf_update_timer_handler(void)
{
    uint8_t update_data = 0;
#ifdef EM
    uint8_t update_area = 0;
#endif

    if (elf_get_config(CFG_UPDATE_TIMEOUT) != 0)
    {
        /* Do not update. */
        update_data = 1;
    }
#ifdef EM
    if (elf_get_config(CFG_UPDATE_AREA_TIMEOUT) != 0)
    {
        /* Do not update. */
        update_area = 1;
    }
#endif

    time_t now = time(NULL);

    if (update_data)
    {
        if (now < update_time) {
            return;
        }

    // todo, this method takes the whole system down every 900 seconds, interrupting BACnet comms,
    // for no good reason. Find another way.. 
    if ((now - update_time) >= elf_get_config(CFG_UPDATE_TIMEOUT))
    {
        update_time = time(NULL);
        log_printf(LOG_INFO, "Update timeout expired");
        elf_devices_setup(false);
        }
    }

#ifdef EM
    if (update_area)
    {
        if (now < update_area_time) {
            return;
        }

        if ((now - update_area_time) >= elf_get_config(CFG_UPDATE_AREA_TIMEOUT))
        {
            update_area_time = time(NULL);
            log_printf(LOG_INFO, "Update area timeout expired");
            elf_update_areas();
        }
    }
#endif

    return;
}

