#ifndef __ELF_CONFIG_H__
#define __ELF_CONFIG_H__

#include "elf_std.h"

// We support 4 modes of operation.
#define MIN_OPER_MODES                   (1)
#define ZONE_ONLY_MODE                   (1)
#define SENSORS_ONLY_MODE                (2)
#define ZONE_SENSORS_MODE                (3)
#define ZONE_SENSORS_DIM_ONLY_MODE       (4)
#define MAX_OPER_MODES                   (4)

#define DEFAULT_VENDOR_ID                (516) /* Read only */
#define DEFAULT_APDU_TIMEOUT             (10*1000) /* Milli-Seconds */
#define DEFAULT_DEV_BASE_INSTANCE        (400000)
#define DEFAULT_LISTEN_PORT              (47808)
#define DEFAULT_MAX_APDU                 (1476) /* Bytes */
#define DEFAULT_NETWORK_ID               (9999)
#define DEFAULT_GEMS_MSG_TIMEOUT         (20) /* Seconds */
#define DEFAULT_MAX_OBJECTS              (40)
#define DEFAULT_VERSION                  (4)
#define DEFAULT_DB_FILE                  ("/var/lib/bacnet/bacnet.db")
#define DEFAULT_GEMS_IP_ADDRESS          ("127.0.0.1")
#define DEFAULT_INTERFACE                ("eth0")
#define DEFAULT_OBJECTS_FILE             ("/var/lib/bacnet/bacnet_objects.cfg")
#define DEFAULT_DIM_DELAY_RESPONSE       (1000)  // milli-seconds
#define DEFAULT_UPDATE_TIMEOUT           (15*60) // Seconds

#ifdef EM
#define DEFAULT_UPDATE_AREA_TIMEOUT      (15) // Seconds
#endif

#define DEFAULT_IGNORE_OWN_BCAST_PACKETS (1)     // Ignore own bcast packets
#define DEFAULT_I_AM_DELAY               (5)     // milli-seconds
#define DEFAULT_DEVICE_NAME_FMT_STR      "COMP-%s/CAMP-%s/BLDG-%s/FL-%s/Z-%s/DEV-%s"
#define DEFAULT_ZONE_OBJECT_NAME_FMT_STR "COMP-%C/CAMP-%c/BLDG-%B/FL-%F/Z-%Z/DEV-%T/PT-%P"
#define DEFAULT_OBJECT_NAME_FMT_STR      "COMP-%s/CAMP-%s/BLDG-%s/FL-%s/Z-%s/DEV-%s/PT-%s"

#ifdef UEM
#define DEFAULT_REST_USERNAME            "admin"
#define DEFAULT_REST_PASSWORD            "admin"
#else
#define DEFAULT_REST_API_APIKEY          "enlighted"
#define DEFAULT_REST_API_SECRET          "enlighted"
#endif

#define DEFAULT_LOG_LEVEL                "info"
#define DEFAULT_MODE                     (ZONE_ONLY_MODE)

typedef enum
{
    CFG_VENDOR_ID = 516, // Read only
    CFG_APDU_TIMEOUT = 1,
    CFG_DEV_BASE_INSTANCE,
    CFG_LISTEN_PORT,
    CFG_MAX_APDU,
    CFG_NETWORK_ID,
    CFG_MSG_TIMEOUT,
    CFG_MAX_OBJECTS,
    CFG_VERSION,
    CFG_DB_FILE,
    CFG_GEMS_IP_ADDRESS,
    CFG_INTERFACE,
    CFG_OBJECTS_FILE_PATH,
    CFG_DIM_DELAY_RESPONSE,
    CFG_UPDATE_TIMEOUT,
#ifdef EM
    CFG_UPDATE_AREA_TIMEOUT,
#endif
    CFG_IGNORE_OWN_BCAST_PACKETS,
    CFG_I_AM_DELAY,
    CFG_DEVICE_NAME_FMT_STR,
    CFG_OBJECT_NAME_FMT_STR,
    CFG_MODE,
} ELF_CONFIG_TYPES;

typedef struct elf_config
{
    uint16_t vendor_id;
    uint16_t apdu_timeout;
    uint32_t device_base_instance;
    uint16_t listen_port;
    uint16_t max_apdu;
    uint16_t network_id;
    uint16_t msg_timeout; // BACnet to GEMS UDP message timeout
    uint16_t max_objects;
    uint32_t dim_delay_response;
    uint8_t  version;
    char     db_file[256];
    char     proxy_ip_address[16];
    char     gems_ip_address[16];
    char     interface[9];
    char     objects_file[256];
    uint16_t update_timeout; // In seconds
#ifdef EM    
    uint16_t update_area_timeout; // In seconds
#endif    
    uint8_t  ignore_own_bcast_packets;
    uint16_t i_am_delay; // In milli-seconds
    uint8_t  device_name_fmt_str[128];
    uint8_t  object_name_fmt_str[128];
    uint8_t  zone_object_name_fmt_str[128];
#ifdef UEM
    char	user_name[128];
    char	password[128];
#else
    uint8_t  rest_api_key[128];
    uint8_t  rest_api_secret[128];
#endif
    char     log_level[64];
    uint8_t  mode; // 1 for zone only, 2 for sensor only, 3 for both
} __attribute__ ((__packed__)) elf_config_t; 

#endif /* __ELF_CONFIG_H__ */
