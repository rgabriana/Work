#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <openssl/sha.h>

#include "config.h"
#include "address.h"
#include "bacdef.h"
#include "handlers.h"
#include "client.h"
#include "dlenv.h"
#include "bacdcode.h"
#include "npdu.h"
#include "apdu.h"
#include "iam.h"
#include "tsm.h"
#include "device.h"
// #include "bacfile.h"
#include "datalink.h"
#include "dcc.h"
#include "net.h"
#include "txbuf.h"
// #include "lc.h"
#include "debug.h"
#include "version.h"

/* include the device object */
#include "device.h"
#ifdef BACNET_TEST_VMAC
#include "vmac.h"
#endif
#include "elf.h"
#include "elf_gems_api.h"
#include <openssl/sha.h>

extern elf_config_t                 elf_bacnet_config;
extern uint16_t                     Num_Managed_Devices;				// maintained by gw_device.c
extern ts_elf_objects_index_list_t *elf_objs_index_list[MAX_DEVICE_TYPES];
extern uint32_t                     g_bacnet_device_count;
extern elf_bacnet_db_t             *g_bacnet_db;

extern void Routing_Device_Init(uint32_t first_object_instance);

uint32_t g_first_device_instance;
uint8_t  elf_mac_address[6];

uint32_t elf_get_device_id(void)
{
    return Routed_Device_Object_Instance_Number();
}

uint16_t elf_get_object_count(uint8_t object_type)
{
    uint16_t count = 0;
    uint32_t id = elf_get_device_id(), num_obj_types = 0;

    if (elf_bacnet_config.mode == ZONE_ONLY_MODE ||
        elf_bacnet_config.mode == ZONE_SENSORS_MODE ||
        elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE)
    {
        count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE, object_type);
    }
    if (elf_bacnet_config.mode == SENSORS_ONLY_MODE ||
        elf_bacnet_config.mode == ZONE_SENSORS_MODE ||
        elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE)
    {
        s_oid_t *sptr = (s_oid_t *)get_zone_oids(id, &num_obj_types);
        if (!sptr) {
            return count;
        }

        int i;
        for (i = 0; i < num_obj_types; i++)
        {
            if (sptr[i].type == object_type)
            {
                count += (sptr[i].num_oids);
                break;
            }
        }
    }
    return count;
}

int8_t elf_index_to_object_instance(unsigned int index, uint8_t object_type,
                                    uint32_t *object_instance)
{
    uint32_t id = elf_get_device_id(), num_obj_types = 0;
    uint8_t ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   object_type);

    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            *object_instance = index;
            return 0;
        }
        return -1;
    }
    else if (elf_bacnet_config.mode == SENSORS_ONLY_MODE)
    {
        s_oid_t *sptr = (s_oid_t *)get_zone_oids(id, &num_obj_types);
        if (!sptr) {
            return -1;
        }

        int i;
        for (i = 0; i < num_obj_types; i++)
        {
            if (sptr[i].type == object_type)
            {
                *object_instance = sptr[i].oid[index];
                return 0;
            }
        }
    }
    else if ((elf_bacnet_config.mode == ZONE_SENSORS_MODE) ||
             (elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE))
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            *object_instance = index;
        }
        else
        {
            s_oid_t *sptr = (s_oid_t *)get_zone_oids(id, &num_obj_types);
            if (!sptr) {
                return -1;
            }

            int i;
            unsigned int new_index = 0;
            if (index > ltg_zone_obj_count) {
                new_index = index - ltg_zone_obj_count;
            }
            log_printf(LOG_INFO, "index=%d,new_index=%d", index, new_index);
            for (i = 0; i < num_obj_types; i++)
            {
                if (sptr[i].type == object_type)
                {
                    *object_instance = sptr[i].oid[new_index];
                    break;
                }
            }
        }
        return 0;
    }

    return -1;
}

int8_t elf_object_instance_to_index(
									// cr00002 not used, taking out for now -- BACNET_OBJECT_TYPE object_type,			// todo, not used anymore? Resolve..
                                    uint32_t object_instance,
									// cr00002 not used, taking out for now --                                     uint8_t *device_type,
                                    uint16_t *tableIndex)
{
	// cr00002 not used, taking out for now --     if (device_type) {
	// cr00002 not used, taking out for now --         *device_type = LTG_ZONE_DEVICE_TYPE;
	// cr00002 not used, taking out for now --     }

    if (tableIndex) {
        *tableIndex = GET_INDEX_FROM_INSTANCE(object_instance);
    }

    return 0;
}

// cr00002 not used, taking out for now -- e_elf_device_t elf_get_device_type(void)
// cr00002 not used, taking out for now -- {
// cr00002 not used, taking out for now -- return LTG_ZONE_DEVICE_TYPE;
// cr00002 not used, taking out for now -- }

static void elf_initialize_device_addresses(uint32_t net_id, uint8_t send_i_am)
{
    int                 i = 0;
    DEVICE_OBJECT_DATA *pDev;
    char                nameText[MAX_DEV_NAME_LEN];

    struct in_addr *netPtr;     /* Lets us cast to this type */
    Routing_Device_Init(0);
    /* Initialize all devices */
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)&g_bacnet_db[0];
    for (i = 0; i < g_bacnet_device_count; i++)
    {
        pDev = Get_Routed_Device_Object(i);
        if (pDev == NULL)
            continue;
#if defined(BACDL_BIP)
        netPtr = (struct in_addr *) &pDev->bacDevAddr.mac[2];

#if 0
        if (i == 0)
        {
            pDev->bacDevAddr.mac[0] = elf_mac_address[0];
            pDev->bacDevAddr.mac[1] = elf_mac_address[1];
            pDev->bacDevAddr.mac[2] = elf_mac_address[2];
            pDev->bacDevAddr.mac[3] = elf_mac_address[3];
            pDev->bacDevAddr.mac[4] = elf_mac_address[4];
            pDev->bacDevAddr.mac[5] = elf_mac_address[5];
        }
        else
#endif
        {
            uint8_t mac[6];
            memset(mac, 0, sizeof(mac));
            get_mac_address(pDev->bacObj.Object_Instance_Number, mac);
            pDev->bacDevAddr.mac[0] = mac[0];
            pDev->bacDevAddr.mac[1] = mac[1];
            pDev->bacDevAddr.mac[2] = mac[2];
            pDev->bacDevAddr.mac[3] = mac[3];
            pDev->bacDevAddr.mac[4] = mac[4];
            pDev->bacDevAddr.mac[5] = mac[5];
            ++ptr;
        }

        pDev->bacDevAddr.mac_len = 6;
        pDev->bacDevAddr.net = net_id;
        memcpy(&pDev->bacDevAddr.adr[0], &pDev->bacDevAddr.mac[0], 6);
        pDev->bacDevAddr.len = 6;

        elf_get_device_object_name(nameText, MAX_DEV_NAME_LEN);
        Routed_Device_Set_Object_Name(CHARACTER_UTF8, nameText, strlen(nameText));

        log_printf(LOG_INFO,
              "Routed device [%d] ID %u %02x:%02x:%02x:%02x:%02x:%02x at "
              "%s", i,
            pDev->bacObj.Object_Instance_Number,
            pDev->bacDevAddr.mac[0], pDev->bacDevAddr.mac[1],
            pDev->bacDevAddr.mac[2], pDev->bacDevAddr.mac[3],
            pDev->bacDevAddr.mac[4], pDev->bacDevAddr.mac[5],
            inet_ntoa(*netPtr));
#endif
        if (send_i_am) {
            /* broadcast an I-Am for each routed Device now */
            Send_I_Am(&Handler_Transmit_Buffer[0]);
        }
    }
}

static void add_devices(void)
{
    int   i;
    char  nameText[MAX_DEV_NAME_LEN];
    char  descText[MAX_DEV_DESC_LEN];
    char *device_type_name = "LTG-ZONE";

#if ( OSS_STACK == NEW_STACK )
    BACNET_CHARACTER_STRING nameTextBCS ;
#endif

    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)&g_bacnet_db[0];
    
    /* Now initialize the Device objects. */
    for (i = 0; i < g_bacnet_device_count; i++, ptr++)
    {
        snprintf(nameText, MAX_DEV_NAME_LEN, "%s %d", "Zone", ptr->bacnet_id);
        snprintf(descText, MAX_DEV_DESC_LEN, "%s %d", "Zone", ptr->bacnet_id);

        log_printf(LOG_INFO, "Adding %s device %d",
                   device_type_name, ptr->bacnet_id);

#if ( OSS_STACK == NEW_STACK )
        characterstring_init_ansi(&nameTextBCS, nameText );
        Add_Routed_Device(ptr->bacnet_id, &nameTextBCS, descText ) ;
#else
        Add_Routed_Device(ptr->bacnet_id, nameText, descText);
#endif
    }
    
}

/** Initialize the Device Objects and each of the child Object instances.
 *  @param first_object_instance Set the first (gateway) Device to this
 *         instance number, and subsequent devices to incremented values.
 */
static void elf_devices_init()
{
    add_devices();
}

#ifdef EM

uint8_t get_auth_token(const char *ts, uint8_t *token)
{
    uint8_t auth_token[20];
    uint8_t buffer[128];
    int i;

    int len = 0;
    len += snprintf((char *)buffer, sizeof(buffer), "%s",
                    elf_get_rest_api_key());
    len += snprintf((char *)buffer+len, sizeof(buffer)-len, "%s",
                    elf_get_rest_api_secret());
    len += snprintf((char *)buffer+len, sizeof(buffer)-len, "%s", ts);

    SHA1(buffer, len, auth_token);

    memset(buffer, 0, sizeof(buffer));

    len = 0;
    for (i = 0; i < sizeof(auth_token); i++)
    {
        len += snprintf((char *)buffer+len, sizeof(buffer)-len,
                        "%02x", auth_token[i]);    
    }

    memcpy((void *)token, (const void *)buffer, len);
    return i;
}
#endif

void elf_devices_setup(uint8_t send_i_am)
{
#ifdef todo			// seems like this was never used
    uint8_t token[41];
    memset(token, 0, sizeof(token));
    get_auth_token("123", token);
#endif

    init_hvac_zone_devices();

    elf_set_device_count(g_bacnet_device_count);
    /* Create BACNET device. Bacnet client discovery is serviced from these
     * created devices.
     */
    elf_create_bacnet_devices();
    log_printf(LOG_INFO, "Successfully created %d BACnet devices",
               MAX_NUM_DEVICES);

    Num_Managed_Devices = 0;

    /* Initialize GEMS device. */
    //Routing_Device_Init(g_first_device_instance);

    /* Setup bacnet devices */
    elf_devices_init();
    elf_initialize_device_addresses(elf_get_config(CFG_NETWORK_ID),
                                    send_i_am);

    /* Write bacnet database to file. */
    if (write_bacnet_db() < 0)
    {
        log_printf(LOG_CRIT, "Failed to write bacnet database.");
        exit(EXIT_FAILURE);
    }

    log_printf(LOG_INFO, "Successfully wrote to bacnet database.");
}

