#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <memory.h>
#include <string.h>
#include <sys/select.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <time.h>
#include <termios.h>
#include <signal.h>

#include "elf_messages.h"

#define RSP_TIMEOUT_WAIT_SECS 5 // Seconds

#define INTERVAL_IN_MINS 5
#define MINUTES_PER_HOUR 60

#define GEMS_RX_DATA_LEN 4096

// Communication for GEMS
#define GEMS_RX_PORT     51367
#define MY_RX_PORT       51368
#define LOCALHOST        "127.0.0.1"

uint32_t elf_device_count = 0;		// todo, what is the difference between this and g_bacnet_device_count
int      elf_gems_sockfd = -1;

uint32_t elf_get_device_count(void) {
    return elf_device_count;
}

static int send_message(int len, void *data) {
    struct sockaddr_in send_addr;
    int                rc; 

    memset(&send_addr, 0, sizeof(send_addr));
    send_addr.sin_family = AF_INET;
    send_addr.sin_port = htons(GEMS_RX_PORT);
    send_addr.sin_addr.s_addr = inet_addr(LOCALHOST);

    rc = sendto(elf_gems_sockfd, data, len, 0,
                (struct sockaddr *)&send_addr, sizeof(send_addr));
}

int elf_send_get_sensor_data_message(uint32_t index, bool receive,
                                     uint8_t *data, uint32_t data_len) {
    NODE_ADDRESS          address[2];
    get_sensor_msg_req_t  *msg;
    int                   rc, i, j;
    fd_set                rfds;
	struct timeval        tv;
    struct sockaddr_in    daddr;
    socklen_t             daddr_len;
    uint8_t              *ptr;
    uint32_t              msg_len = 0, num_nodes = 2;

    elf_get_node_address_by_index(index, address);
    elf_get_node_address_by_index(index+1, &address[1]);

    msg_len += sizeof(message_hdr_t);
    msg_len += sizeof(uint16_t);
    msg_len += sizeof(NODE_ADDRESS) * num_nodes;

    msg = (get_sensor_msg_req_t *)calloc(1, msg_len);

    msg->hdr.type = REQ_CMD;
    msg->hdr.ver = 37;
    msg->num_nodes = htons(num_nodes);
    msg->hdr.len = htons(msg_len);
    msg->hdr.txid = htonl(0xDDEEAADD);
    msg->hdr.cmd = GET_SENSOR_DATA;
    memcpy(&msg->address, &address[0], num_nodes*sizeof(NODE_ADDRESS));
//    memcpy(msg->address[1], &address[1], sizeof(NODE_ADDRESS));
    //msg.address[0] = 0x0A;
    //msg.address[1] = 0x0B;
    //msg.address[2] = 0x0C;

    send_message(msg_len, (void *)msg);

    free(msg);

    rc = 0;
    if (receive) {
        tv.tv_sec = RSP_TIMEOUT_WAIT_SECS;
        tv.tv_usec = 1000;

        FD_ZERO(&rfds);
        FD_SET(elf_gems_sockfd, &rfds);

        rc = select(elf_gems_sockfd+1, &rfds, NULL, NULL, &tv);
        if (rc > 0) {
            printf("Found something on fd\n");
            if (FD_ISSET(elf_gems_sockfd, &rfds)) {
                rc = recvfrom(elf_gems_sockfd, data, data_len, 0,
                              (struct sockaddr *)&daddr, &daddr_len);
                return 0;
            }
        }
    }

    return rc;
}

int elf_send_discover_sensor_message(bool receive) {
    discover_msg_req_t    msg;
    NODE_ADDRESS          address;
    int                   rc;
    fd_set                rfds;
    uint8_t               data_buf[GEMS_RX_DATA_LEN];
	struct timeval        tv;
    struct sockaddr_in    daddr;
    socklen_t             daddr_len;
    discover_msg_rsp_t   *ptr;

    printf("In %s function\n", __FUNCTION__);

    memset(&msg, 0, sizeof(discover_msg_req_t));

    msg.hdr.type = REQ_CMD;
    msg.hdr.ver = 37;
    msg.hdr.len = htons(sizeof(discover_msg_req_t));
    msg.hdr.txid = htonl(0xDDEEAADD);
    msg.hdr.cmd = DISCOVER_SENSOR;

    send_message(sizeof(discover_msg_req_t), (void *)&msg);

    if (receive) {
        tv.tv_sec = RSP_TIMEOUT_WAIT_SECS;
        tv.tv_usec = 0;
    
        FD_ZERO(&rfds);
        FD_SET(elf_gems_sockfd, &rfds);
    
        rc = select(elf_gems_sockfd+1, &rfds, NULL, NULL, &tv);
        if ((rc > 0) && (FD_ISSET(elf_gems_sockfd, &rfds))) {
            printf("Got something on Fd\n");
            if (FD_ISSET(elf_gems_sockfd, &rfds)) {
                rc = recvfrom(elf_gems_sockfd, data_buf, sizeof(data_buf), 0,
                              (struct sockaddr *)&daddr, &daddr_len);
                ptr = (discover_msg_rsp_t *)data_buf;
                elf_device_count = ntohs(ptr->num_nodes);
                printf("Device count = %d\n", elf_device_count);
                elf_init_sensors(ptr->data);
            }
        }
        else if (rc == 0) {
            printf("Timed out\n");
        }
    }

    return 0;
}

int elf_gems_comm_init(void) {
    struct sockaddr_in addr;
    int                rc;

    printf("In %s function\n", __FUNCTION__);

    if((elf_gems_sockfd  = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        printf("\nError %s creating socket\n", strerror(errno));
        exit(1);
    }

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(MY_RX_PORT);
	addr.sin_addr.s_addr = inet_addr(LOCALHOST);

	rc = bind(elf_gems_sockfd, (struct sockaddr *)&addr, sizeof(addr));
	if(rc < 0) {
    	printf("\nError %s binding socket\n", strerror(errno));
    	exit(1);
	}

    return 0;
}

int main(void) {
    int i, rc;
    uint8_t               buffer[1024];
    get_sensor_msg_rsp_t *ptr;
    sensor_data_t        *su_data;

    elf_gems_comm_init();

    elf_send_discover_sensor_message(1);
    rc = elf_send_get_sensor_data_message(0, 1, buffer, 1024);

    if (rc == 0) {
    ptr = (get_sensor_msg_rsp_t *)buffer;

    printf("Num nodes = %d\n", ntohs(ptr->num_nodes));
    su_data = (sensor_data_t *)&ptr->data;
    for (i = 0; i < ntohs(ptr->num_nodes); i++, su_data++) {
        printf("Address is %02x:%02x:%02x\n",
                su_data->address[0], su_data->address[1], su_data->address[2]);
        printf("Version = %s\n", su_data->version);
        printf("Light Status = %d\n", su_data->light_status);
        printf("Load = %d\n", su_data->load);
        printf("Occupancy = %d\n", su_data->occupancy);
    }
    }

    return 0;
}
