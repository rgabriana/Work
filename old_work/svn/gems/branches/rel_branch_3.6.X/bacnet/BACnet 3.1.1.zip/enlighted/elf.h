#ifndef __ELF_H__
#define __ELF_H__

#include "elf_std.h"
#include "elf_objects.h"
#include "elf_config.h"
#include "elf_functions.h"
#include "elf_messages.h"
#include "elf_objects.h"

#define BACNET_LOG_NAME "bacnetd"

extern DEVICE_OBJECT_DATA *Devices;
extern uint16_t iCurrent_Device_Idx;
#define GET_CUR_DEVICE_INDEX (iCurrent_Device_Idx)

#if 0
#define log_printf(level, ...) ((level <= g_log_level) ? syslog(level, __VA_ARGS__) : ##__VA_ARGS__)
#endif

typedef enum device_state
{
    DEVICE_STATE_INIT = 0,
    DEVICE_STATE_VALID,
    DEVICE_STATE_INVALID,
} e_device_state_t;

/* bacnet db is stored in csv format in sorted bacnet id order.
 */
typedef struct elf_bacnet_db
{
    uint32_t bacnet_id;
    uint32_t floor_id;
    uint32_t zone_id;
    uint8_t  zone_type;
    uint8_t  state;
    uint32_t update_ts; // last updated timestamp (kept in memory only)
} __attribute__ ((__packed__)) elf_bacnet_db_t;

#endif /* __ELF_H__ */
