#include "elf.h"

extern elf_config_t          elf_bacnet_config;
ts_elf_objects_t            *elf_objs;
ts_elf_objects_index_list_t *elf_objs_index_list[MAX_DEVICE_TYPES];

bool elf_is_object_index_valid(uint8_t enl_obj_type, uint16_t object_type,
                               uint8_t index)
{
    ts_elf_objects_t *optr = (ts_elf_objects_t *)elf_objs;

    for (; optr->name[0]; optr++)
    {
        if (((optr->enl_obj_type == enl_obj_type)) &&
             (optr->bacnet_obj_type == object_type) &&
             (optr->index_valid == true))
        {
            return true;
        }
    }

    return false;
}

uint16_t elf_get_number_of_objects(uint8_t enl_obj_type, uint16_t object_type)
{
    uint16_t          count = 0;
    ts_elf_objects_t *optr = (ts_elf_objects_t *)elf_objs;

    for (; optr->name[0]; optr++)
    {
        if (((optr->enl_obj_type == enl_obj_type)) &&
             (optr->bacnet_obj_type == object_type) &&
             (optr->index_valid == true))
        {
            ++count;
        }
    }

    return count;
}

ts_elf_objects_t *elf_get_object_by_type_instance(BACNET_OBJECT_TYPE bacnet_object_type, uint32_t bacnet_object_instance )
{
	// cr00002 - uint8_t type ;
	uint16_t ourIndex ;

	// int8_t  rc =
    		elf_object_instance_to_index( // cr00002 not used, taking out for now -- bacnet_object_type,
                                                        bacnet_object_instance,
														// cr00002 not used, taking out for now -- &type,
                                                        &ourIndex);

    return elf_get_object_by_type( bacnet_object_type, ourIndex, OBJECT_ASSIGNED_INDEX ) ;
}

ts_elf_objects_t *elf_get_object_by_type(BACNET_OBJECT_TYPE bacnet_object_type, uint8_t index, uint8_t index_type)
{
    ts_elf_objects_t *optr = elf_objs;
    uint8_t           enl_obj_type = 0;
    uint8_t           ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   bacnet_object_type);

    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            enl_obj_type = LTG_ZONE_OBJECT_TYPE;
        }
    }
    else if (elf_bacnet_config.mode == SENSORS_ONLY_MODE)
    {
        enl_obj_type = SENSOR_OBJECT_TYPE;
    }
    else if ((elf_bacnet_config.mode == ZONE_SENSORS_MODE) ||
             (elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE))
    {
        if (index < ltg_zone_obj_count)
        {
            enl_obj_type = LTG_ZONE_OBJECT_TYPE;
        }
        else {
            enl_obj_type = SENSOR_OBJECT_TYPE;
        }
    }
	
    // EKH: OBJECT_CFG_INDEX removed, see cr00001
//    if (type == OBJECT_CFG_INDEX) {
    	// todo - understand why index types are switched
//        type = OBJECT_ASSIGNED_INDEX;
//    }

    for (; optr->name[0]; optr++)
    {
        if (((optr->enl_obj_type == enl_obj_type)) &&
             (optr->bacnet_obj_type == bacnet_object_type) &&
			 // EKH: OBJECT_CFG_INDEX removed, see cr00001
             // ((type == OBJECT_CFG_INDEX ? optr->cfg_index : optr->assigned_index) == index) && (optr->index_valid == true))
				(optr->index_valid == true ) &&
			 optr->cfg_index == index )
        {
            return optr;
        }
    }

    return NULL;
}

// EKH: OBJECT_CFG_INDEX removed, see cr00001
#if 0
int16_t elf_get_object_cfg_index(uint16_t object_type, uint8_t index)
{
    ts_elf_objects_t *optr = (ts_elf_objects_t *)elf_objs;
    uint8_t           enl_obj_type = 0;
    uint8_t           ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   object_type);

    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            enl_obj_type = LTG_ZONE_OBJECT_TYPE;
        }
    }
    else if (elf_bacnet_config.mode == SENSORS_ONLY_MODE)
    {
        enl_obj_type = SENSOR_OBJECT_TYPE;
    }
    else if (elf_bacnet_config.mode == ZONE_SENSORS_MODE)
    {
        if (index < ltg_zone_obj_count)
        {
            enl_obj_type = LTG_ZONE_OBJECT_TYPE;
        }
        else {
            enl_obj_type = SENSOR_OBJECT_TYPE;
        }
    }

    for (; optr->name[0]; optr++)
    {
        if (((optr->enl_obj_type == enl_obj_type)) &&
             (optr->bacnet_obj_type == object_type) &&
             (optr->assigned_index == index) &&
             (optr->index_valid == true))
        {
            return optr->cfg_index;
        }
    }

    return -1;
}
#endif

extern bool elf_valid_object_instance(BACNET_OBJECT_TYPE bacType,
		uint32_t instance) {
	ts_elf_objects_t *optr = (ts_elf_objects_t *) elf_objs;
	// cr00002 - uint8_t device_type = elf_get_device_type();


	for (; optr->name[0]; optr++) {
		if ((optr->bacnet_obj_type == bacType )
				&& (optr->cfg_index == instance ))
				{
			return true ;
		}
	}
	return false ;
}

int8_t elf_objects_setup(void)
{
    FILE     *fp;
    char      buffer[128];
    uint8_t   i, max_objects = MAX_OBJECTS;
    char     *ptr = NULL, *tptr = buffer;

    if ( (fp = fopen(elf_get_objects_file(), "r")) == NULL)
    {
        fprintf(stderr, "\nError opening bacnet objects file\n");
        exit(1);
    }

    /* Pre-allocate objects. */
    elf_objs = (ts_elf_objects_t *) calloc((max_objects+1),
                                           sizeof(ts_elf_objects_t));
    if (elf_objs == NULL)
    {
        log_printf(LOG_CRIT, "%s:%d - Error allocating memory",
                   __FUNCTION__, __LINE__);
        exit(EXIT_FAILURE);
    }

    uint8_t           		device_index = 5, count, num_objs = 0;
    e_elf_object_types_t    enl_obj_type;
    char             *nptr[10];
    ts_elf_objects_t *obj_ptr;

    while (fgets(buffer, sizeof(buffer), fp) != NULL)
    {
        if (buffer[0] == '#') {
            continue;
        }
        count = 0;
        enl_obj_type = LTG_ZONE_OBJECT_TYPE;		// the default? (was = 0)
        buffer[strlen(buffer)-1] = 0;
        obj_ptr = (ts_elf_objects_t *)&elf_objs[num_objs];

        while ((tptr = strtok_r(tptr, "::", &ptr)) != NULL)
        {
            nptr[count++] = tptr;
            tptr = NULL;
        }

#if 0
        if (!atoi(nptr[5]))
        {
            /* skip if not valid */
            tptr = buffer;
            continue;
        }
#endif

        for (--count; count >= device_index; count--)
        {
            if (!strcasecmp(nptr[count], "ltg-zone"))
            {
                /* Lighting Zone Device */
                enl_obj_type = LTG_ZONE_OBJECT_TYPE;
            }
            else if (!strcasecmp(nptr[count], "sensor"))
            {
                /* Sensor Device */
                enl_obj_type = SENSOR_OBJECT_TYPE;
            }
            else if (!strcasecmp(nptr[count], "hvac-zone"))
            {
                /* HVAC Zone Device */
                enl_obj_type = HVAC_ZONE_OBJECT_TYPE;
            }
        }

        obj_ptr->bacnet_obj_type = atoi(nptr[0]);
        strcpy(obj_ptr->name, nptr[1]);
        strcpy(obj_ptr->description, nptr[2]);
        obj_ptr->units = atoi(nptr[3]);
        obj_ptr->cfg_index = atoi(nptr[4]);
        if ((elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE) &&
            (enl_obj_type == SENSOR_OBJECT_TYPE))
        {
            obj_ptr->index_valid = atoi(nptr[5]);
            if (strcasecmp(obj_ptr->name, "DIM_LEVEL"))
            {
                // Disable all objects other than DIM_LEVEL to false.
                obj_ptr->index_valid = false;
            }
        }
        else {
            obj_ptr->index_valid = atoi(nptr[5]);
        }

        obj_ptr->enl_obj_type = enl_obj_type;
        //obj_ptr->assigned_index = index[device][obj_ptr->obj_type]++;
        // EKH: OBJECT_CFG_INDEX removed, see cr00001
        // obj_ptr->assigned_index = obj_ptr->cfg_index;

        tptr = buffer;
        ++num_objs;
        if (num_objs == max_objects)
        {
            break;
        }
    }

    log_printf(LOG_INFO, "Reading objects list");
    for (i = 0; i < num_objs; i++)
    {
        log_printf(LOG_INFO, "bacnet obj type = %d",
                   elf_objs[i].bacnet_obj_type);
        log_printf(LOG_INFO, "name = %s", elf_objs[i].name);
        log_printf(LOG_INFO, "description = %s", elf_objs[i].description);
        log_printf(LOG_INFO, "units = %d", elf_objs[i].units);
        // EKH: OBJECT_CFG_INDEX removed, see cr00001
        log_printf(LOG_INFO, "config index = %d", elf_objs[i].cfg_index);
        // log_printf(LOG_INFO, "assigned index = %d", elf_objs[i].assigned_index);
        // EKH: OBJECT_CFG_INDEX removed, see cr00001
        log_printf(LOG_INFO, "index valid = %d", elf_objs[i].index_valid);
        log_printf(LOG_INFO, "enl obj type = %d(%s)", elf_objs[i].enl_obj_type,
                   (elf_objs[i].enl_obj_type == LTG_ZONE_OBJECT_TYPE) ? "ltg-zone" : "sensor");
    }

    log_printf(LOG_INFO, "num objects = %d", num_objs);

    ts_elf_objects_index_t *iptr = NULL;
    uint8_t                 j = 0;
    for (i = 0; i < MAX_DEVICE_TYPES; i++)
    {
        elf_objs_index_list[i] = calloc(1, sizeof(ts_elf_objects_index_list_t));
        if (elf_objs_index_list[i] == NULL)
        {
            log_printf(LOG_CRIT,
                       "Unable to allocate memory for objects index list");
            exit(EXIT_FAILURE);
        }
        elf_objs_index_list[i]->index_ptr = calloc(MAX_OBJECT_TYPES_PER_DEVICE, sizeof(ts_elf_objects_index_t));
        if (elf_objs_index_list[i]->index_ptr == NULL)
        {
            log_printf(LOG_CRIT, "Unable to allocate memory for objects index");
            exit(EXIT_FAILURE);
        }

        iptr = (ts_elf_objects_index_t *)elf_objs_index_list[i]->index_ptr;
        for (j = 0; j < MAX_OBJECT_TYPES_PER_DEVICE; j++, iptr++)
        {
            iptr->enl_obj_type = i;
            iptr->bacnet_obj_type = 0xFFFF;
        }
    }

    for (i = 0; i < num_objs; i++)
    {
        // Point to the device
        iptr = (ts_elf_objects_index_t *)elf_objs_index_list[elf_objs[i].enl_obj_type]->index_ptr;
        for (j = 0; j < MAX_OBJECT_TYPES_PER_DEVICE; j++, iptr++)
        {
            if (iptr->bacnet_obj_type == 0xFFFF)
            {
                iptr->bacnet_obj_type = elf_objs[i].bacnet_obj_type;
            }
            if (iptr->bacnet_obj_type == elf_objs[i].bacnet_obj_type)
            {
                // Found object type
                if (elf_objs[i].index_valid)
                {
                	// EKH: OBJECT_CFG_INDEX removed, see cr00001
                    // iptr->valid_obj_index[iptr->valid_obj_count++] = elf_objs[i].assigned_index;
                	iptr->valid_obj_index[iptr->valid_obj_count++] = elf_objs[i].cfg_index;
                }
                break;
            }
        }
    }
    return 0;
}
