#include "elf_std.h"
#include "elf.h"
#include "elf_gems_api.h"

extern elf_config_t elf_bacnet_config;

const char *elf_get_ai_name(uint32_t object_instance, char *name)
{
    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_INPUT)) {
        return "Unknown";
    }
    return elf_get_object_name(OBJECT_ANALOG_INPUT, object_instance, name);
}

const char *elf_get_ai_description(uint32_t object_instance)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;
    int8_t            rc = -1;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_INPUT)) {
        return "Unknown";
    }

    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_INPUT,
										object_instance,
										// cr00002 not used, taking out for now --                                       	NULL,
										&index);
    if (rc < 0) {
        return "Unknown";
    }

    ptr = elf_get_object_by_type(OBJECT_ANALOG_INPUT, index, OBJECT_CFG_INDEX);
    if (ptr) {
        return ptr->description;
    }

    return "Unknown";
}

BACNET_ENGINEERING_UNITS elf_get_ai_units(uint32_t object_instance)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;
    int8_t            rc = -1;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_INPUT)) {
        return 0;
    }

    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_INPUT,
    		object_instance,
			// cr00002 not used, taking out for now -- NULL,
			&index);
    if (rc < 0) {
        return 0;
    }

    ptr = elf_get_object_by_type(OBJECT_ANALOG_INPUT, index, OBJECT_CFG_INDEX);
    if (ptr) {
        return ptr->units;
    }

    return 0;
}

float elf_get_ai_present_value(uint32_t object_instance)
{
    int       rc = 0;
    uint16_t  index = 0;
    // cr00002 not used, taking out for now -- uint8_t   device_type = 0;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_INPUT)) {
        return 0.0;
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- BJECT_ANALOG_INPUT,
    		object_instance,
    		// cr00002 not used, taking out for now -- &device_type,
    		&index);
    if (rc < 0) {
        return 0.0;
    }

#ifdef UEM
    float max_temp ;
    float min_temp ;
    float avg_temp ;
    float setback ;
#else
    uint8_t dim_level = 0;
    float   base_energy = 0;
    float   used_energy = 0;
    float   saved_energy = 0;
    float   occ_saved_energy = 0;
    float   amb_saved_energy = 0;
    float   task_saved_energy = 0;
    float   manual_saved_energy = 0;
#endif

    s_zone_t *zptr;
    uint32_t id = elf_get_device_id();
    uint8_t  ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   OBJECT_ANALOG_INPUT);
    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            zptr = (s_zone_t *)get_zone_data(id);
            if (!zptr) {
                return 0.0;
            }
#ifdef UEM
            min_temp = zptr->min_temp ;
            max_temp = zptr->max_temp ;
            avg_temp = zptr->avg_temp ;
            setback = zptr->setback;
#else
            dim_level = zptr->avg_dim_level;
            base_energy = zptr->base_energy;
            used_energy = zptr->used_energy;
            saved_energy = zptr->saved_energy;
            occ_saved_energy = zptr->occ_saved_energy;
            amb_saved_energy = zptr->amb_saved_energy;
            task_saved_energy = zptr->task_saved_energy;
            manual_saved_energy = zptr->manual_saved_energy;
#endif
            free(zptr);
        }
    }
#ifdef EM
    else if (elf_bacnet_config.mode == SENSORS_ONLY_MODE)
    {
        s_sensor_t *sptr = (s_sensor_t *)get_sensor_data(id, object_instance);
        if (!sptr) {
            return 0.0;
        }
        base_energy = sptr->base_energy;
        used_energy = sptr->used_energy;
        saved_energy = sptr->saved_energy;
        occ_saved_energy = sptr->occ_saved_energy;
        amb_saved_energy = sptr->amb_saved_energy;
        task_saved_energy = sptr->task_saved_energy;
        manual_saved_energy = sptr->manual_saved_energy;
    }
    else if ((elf_bacnet_config.mode == ZONE_SENSORS_MODE) ||
             (elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE))
    {
        if (index < ltg_zone_obj_count)
        {
            zptr = (s_zone_t *)get_zone_data(id);
            if (!zptr) {
                return 0.0;
            }
            dim_level = zptr->avg_dim_level;
            base_energy = zptr->base_energy;
            used_energy = zptr->used_energy;
            saved_energy = zptr->saved_energy;
            occ_saved_energy = zptr->occ_saved_energy;
            amb_saved_energy = zptr->amb_saved_energy;
            task_saved_energy = zptr->task_saved_energy;
            manual_saved_energy = zptr->manual_saved_energy;
            free(zptr);
        }
        else
        {
            if (elf_bacnet_config.mode == ZONE_SENSORS_MODE)
            {
                s_sensor_t *sptr = (s_sensor_t *)get_sensor_data(id, object_instance);
                if (!sptr) {
                    return 0.0;
                }
                base_energy = sptr->base_energy;
                used_energy = sptr->used_energy;
                saved_energy = sptr->saved_energy;
                occ_saved_energy = sptr->occ_saved_energy;
                amb_saved_energy = sptr->amb_saved_energy;
                task_saved_energy = sptr->task_saved_energy;
                manual_saved_energy = sptr->manual_saved_energy;
            }
            else {
                return 0.0;
            }
        }
    }
#endif

#ifdef UEM
    switch (index)
    {
        case ELF_AI_ZONE_MAX_TEMP:
            return max_temp;
        case ELF_AI_ZONE_MIN_TEMP:
            return min_temp;
        case ELF_AI_ZONE_AVG_TEMP:
            return avg_temp;
        case ELF_AI_ZONE_SETBACK:
            return setback;
    }
#else
    switch (index)
    {
        case ELF_AI_ZONE_DIM_LEVEL_OBJECT:
        {
            return dim_level;
        }
        case ELF_AI_ZONE_BASE_ENERGY_OBJECT:
        case ELF_AI_BASE_ENERGY_OBJECT:
        {
            return base_energy;
        }
        case ELF_AI_ZONE_USED_ENERGY_OBJECT:
        case ELF_AI_USED_ENERGY_OBJECT:
        {
            return used_energy;
        }
        case ELF_AI_ZONE_SAVED_ENERGY_OBJECT:
        case ELF_AI_SAVED_ENERGY_OBJECT:
        {
            return saved_energy;
        }
        case ELF_AI_ZONE_OCC_SAVED_ENERGY_OBJECT:
        case ELF_AI_OCC_SAVED_ENERGY_OBJECT:
        {
            return occ_saved_energy;
        }
        case ELF_AI_ZONE_AMB_SAVED_ENERGY_OBJECT:
        case ELF_AI_AMB_SAVED_ENERGY_OBJECT:
        {
            return amb_saved_energy;
        }
        case ELF_AI_ZONE_TASK_SAVED_ENERGY_OBJECT:
        case ELF_AI_TASK_SAVED_ENERGY_OBJECT:
        {
            return task_saved_energy;
        }
        case ELF_AI_ZONE_MANUAL_SAVED_ENERGY_OBJECT:
        case ELF_AI_MANUAL_SAVED_ENERGY_OBJECT:
        {
            return manual_saved_energy;
        }
    }
#endif
    return 0.0;
}

