#include "elf.h"
#include "elf_gems_api.h"

extern uint32_t         g_max_bacnet_id;
extern elf_bacnet_db_t *g_bacnet_db;
extern s_floor_list_t  *g_floor_list;
extern uint32_t         g_bacnet_device_count;

extern int sync_data_from_em(void);

void get_mac_address(uint32_t bacnet_id, uint8_t *mac)
{
    memset(mac, 0, 6);
    mac[3] = ((bacnet_id >> 16) & 0xFF);
    mac[4] = ((bacnet_id >> 8) & 0xFF);
    mac[5] = (bacnet_id & 0xFF);
}

int init_hvac_zone_devices(void)
{
    // Go through g_bacnet_db array of devices and mark them as invalid.
    // Go through all the floors and its areas and update or add to 
    // g_bacnet_db
    init_bacnet_db();
    read_bacnet_db();
    mark_bacnet_db();

    // Get all zones from EM
    sync_data_from_em();
    if (!g_floor_list)
    {
        log_printf(LOG_CRIT, "%s:%d: g_floor_list=NULL - TODO: Is proxy missing??");
        exit(EXIT_FAILURE);
    }

    // update bacnet db
    int i, j, k, found;
    elf_bacnet_db_t *ptr = g_bacnet_db;
    for (i = 0; i < g_floor_list->num_floors; i++)
    {
        for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
        {
            ptr = g_bacnet_db;
            found = 0;
            for (k = 0; k < g_bacnet_device_count; k++, ptr++)
            {
                if ((g_floor_list->floors[i].id == ptr->floor_id) &&
                    (g_floor_list->floors[i].s_area[j].id == ptr->zone_id) &&
                    (g_floor_list->floors[i].s_area[j].type == ptr->zone_type))
                {
                    // Device exists in db and is valid
                    ptr->state = DEVICE_STATE_VALID;
                    update_bacnet_db((uint8_t *)ptr);
                    found = 1;
                    break;
                }
            }

            if (!found)
            {
                // Device does not exist in db. Create it.
                elf_bacnet_db_t bacnet_db;
                memset((void *)&bacnet_db, 0, sizeof(bacnet_db));
                bacnet_db.bacnet_id = g_max_bacnet_id;
                bacnet_db.floor_id = g_floor_list->floors[i].id;
                bacnet_db.zone_id = g_floor_list->floors[i].s_area[j].id;
                bacnet_db.zone_type = g_floor_list->floors[i].s_area[j].type;
                add_to_bacnet_db((uint8_t *)&bacnet_db);
                bacnet_db.state = DEVICE_STATE_VALID;
            }
        }
    }
    return 0;
}

