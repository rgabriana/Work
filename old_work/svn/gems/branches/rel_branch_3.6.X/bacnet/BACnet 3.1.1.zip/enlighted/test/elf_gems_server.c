#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <memory.h>
#include <string.h>
#include <sys/select.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <time.h>
#include <termios.h>
#include <signal.h>

#include "elf_messages.h"

#define RSP_TIMEOUT_WAIT_SECS 5 // Seconds

#define INTERVAL_IN_MINS 5
#define MINUTES_PER_HOUR 60

#define GEMS_RX_DATA_LEN 4096

// Communication for GEMS
#define GEMS_RX_PORT     51367
#define MY_RX_PORT       51368
#define LOCALHOST        "127.0.0.1"

uint32_t elf_device_count = 0;
int      elf_gems_sockfd = -1;
uint16_t dim = 31;

uint32_t elf_get_device_count(void) {
    return elf_device_count;
}

static int send_message(int len, void *data) {
    struct sockaddr_in send_addr;
    int                rc; 

    memset(&send_addr, 0, sizeof(send_addr));
    send_addr.sin_family = AF_INET;
    send_addr.sin_port = htons(51368);
    send_addr.sin_addr.s_addr = inet_addr(LOCALHOST);

    printf("%s\n", __FUNCTION__);
    rc = sendto(elf_gems_sockfd, data, len, 0,
                (struct sockaddr *)&send_addr, sizeof(send_addr));

    printf("rc = %d\n", rc);
    return rc;
}

#if 0
typedef struct message_header {
    uint8_t   type;
    uint8_t   ver;
    uint16_t  len;
    uint32_t  txid;   
    uint8_t   cmd;
    uint8_t   flags;
    uint8_t   rsvd;
} __attribute__ ((__packed__)) message_hdr_t;

typedef struct request_message {
    message_hdr_t   hdr;
    uint8_t         data[];
} __attribute__ ((__packed__)) req_message_t;

typedef struct response_message {
    message_hdr_t   hdr;
    uint8_t         data[];
} __attribute__ ((__packed__)) rsp_message_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[];
} __attribute__ ((__packed__)) discover_msg_rsp_t;

typedef struct {
    uint8_t       address[3];
    uint32_t      id;
    uint8_t       state;
} __attribute__ ((__packed__)) gems_device_t;
#endif
  
int num_nodes = 1;

int msg_1_hndlr(void *data) {
    discover_msg_rsp_t *msg;
    gems_device_t *ptr;
    int msg_len = 0, i, rc = 0;

    printf("In %s\n", __FUNCTION__);
    msg_len += sizeof(message_hdr_t);
    msg_len += sizeof(uint16_t);
    msg_len += (num_nodes * sizeof(gems_device_t));

    msg = calloc(1, msg_len);
    if (msg) {
        msg->hdr.type = 2;
        msg->hdr.ver = 1;
        msg->hdr.len = htons(msg_len);
        msg->hdr.txid = htonl(1);
        msg->hdr.cmd = 1;
        msg->num_nodes = htons(num_nodes);
        ptr = (gems_device_t *)msg->data;
        for (i = 0; i < num_nodes; i++, ptr++) {
            ptr->address[0] = i; 
            ptr->address[1] = i+1; 
            ptr->address[2] = i+2; 
            ptr->id = htonl((i+1));
            ptr->state = 1;
        }
    }

    rc = send_message(msg_len, msg);
    free(msg);
    return rc;
}

int msg_2_hndlr(void *data) {
    return 0;
}

#if 0
typedef struct {
    NODE_ADDRESS  address;
    uint8_t       version[12];
    uint8_t       light_status;
    uint16_t      load;
    uint8_t       occupancy;
} __attribute__ ((__packed__)) sensor_data_t;

typedef struct {
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[];
} __attribute__ ((__packed__)) get_sensor_msg_rsp_t;

typedef struct {
    NODE_ADDRESS  address;
    uint8_t       version[12];
    uint8_t       light_status;
    uint16_t      load;
    uint8_t       occupancy;
} __attribute__ ((__packed__)) sensor_data_t;

#endif

int msg_3_hndlr(void *data) {
    get_sensor_by_id_msg_req_t *msg_req;
    get_sensor_msg_rsp_t       *msg_rsp;
    sensor_data_t              *s_data;
    uint32_t msg_len = 0;
    uint32_t id;
    int rc;

    msg_req = (get_sensor_by_id_msg_req_t *)data;
    memcpy(&id, &msg_req->id, sizeof(uint32_t));
    id = ntohl(id);

    printf("%s: Receieved get sensor for id %d\n", __FUNCTION__, (int)id);

    msg_len += sizeof(message_hdr_t);
    msg_len += sizeof(uint16_t);
    msg_len += sizeof(sensor_data_t);

    printf("msg_len = %d\n", msg_len);
    msg_rsp = calloc(1, msg_len);
    if(msg_rsp) {
        msg_rsp->hdr.type = 2;
        msg_rsp->hdr.ver = 1;
        msg_rsp->hdr.len = htons(msg_len);
        msg_rsp->hdr.txid = htonl(1);
        msg_rsp->hdr.cmd = 1;
        msg_rsp->num_nodes = htons(1);
        s_data = (sensor_data_t *)msg_rsp->data;
        s_data->address[0] = (id-1);
        s_data->address[1] = (id-1)+1;
        s_data->address[2] = (id-1)+2;
        strcpy(s_data->version, "1.3.0 b399");
        s_data->light_status = 0;
        s_data->occupancy = 1;
        s_data->load = htons(id+1);
        s_data->dim = htons(dim);
    }
    rc = send_message(msg_len, msg_rsp);
    free(msg_rsp);
    return 0;
}

int msg_5_hndlr(void *data) {
    set_sensor_dim_msg_req_t *req = (set_sensor_dim_msg_req_t *)data;
    set_sensor_dim_req_t *ptr = (set_sensor_dim_req_t *)req->data;
    set_sensor_dim_msg_rsp_t *msg_rsp;
    set_sensor_dim_rsp_t *rsp_ptr;
    int rc, msg_len = 0;

    dim = ntohs(ptr->value);
    printf("In %s function, id = %d, type = %d, value = %d\n",
           __FUNCTION__, ntohl(ptr->u.id), ptr->type, ntohs(ptr->value));

    msg_rsp = calloc(1, msg_len);

    msg_len += sizeof(message_hdr_t);
    msg_len += sizeof(uint16_t);
    msg_len += sizeof(set_sensor_dim_rsp_t);

    msg_rsp->hdr.type = 2;
    msg_rsp->hdr.ver = 1;
    msg_rsp->hdr.len = htons(sizeof(msg_len));
    msg_rsp->hdr.txid = htonl(1);
    msg_rsp->hdr.cmd = 0x05;
    msg_rsp->num_nodes = htons(1);

    rsp_ptr = (set_sensor_dim_rsp_t *)&msg_rsp->data;
    rsp_ptr->u.id = ptr->u.id;

    rc = send_message(msg_len, msg_rsp);
    free(msg_rsp);
    return 0;
}

int msg_81_hndlr(void *data) {
    get_gems_data_msg_rsp_t msg_rsp;
    int rc, msg_len = 0;

    printf("In %s function\n", __FUNCTION__);
    memset((void *)&msg_rsp, 0, sizeof(msg_rsp));

    msg_rsp.hdr.type = 2;
    msg_rsp.hdr.ver = 1;
    msg_rsp.hdr.len = htons(sizeof(msg_rsp));
    msg_rsp.hdr.txid = htonl(1);
    msg_rsp.hdr.cmd = 0x81;

    strcpy(msg_rsp.version, "1.4.0.GEMS");

    rc = send_message(sizeof(msg_rsp), &msg_rsp);
    return 0;
}

int elf_gems_comm_init(void) {
    struct sockaddr_in addr;
    int                rc;

    printf("In %s function\n", __FUNCTION__);

    if((elf_gems_sockfd  = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        printf("\nError %s creating socket\n", strerror(errno));
        exit(1);
    }

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(51367);
	addr.sin_addr.s_addr = inet_addr(LOCALHOST);

	rc = bind(elf_gems_sockfd, (struct sockaddr *)&addr, sizeof(addr));
	if(rc < 0) {
    	printf("\nError %s binding socket\n", strerror(errno));
    	exit(1);
	}

    return 0;
}

int main(int argc, char *argv[]) {
    int i, rc;
    uint8_t               data[1024];
    size_t                data_len = 0;
    get_sensor_msg_rsp_t *ptr;
    fd_set                rfds;
    struct sockaddr_in    daddr;
    socklen_t             daddr_len;
    message_hdr_t         *msg_hdr;

    if (argc != 2) {
        fprintf(stderr, "\nUsage: ./a.out <num-nodes>\n");
        exit(1);
    }

    num_nodes = atoi(argv[1]);
    printf("num nodes = %d\n", num_nodes);
    elf_gems_comm_init();

    while (1) {
        FD_ZERO(&rfds);
        FD_SET(elf_gems_sockfd, &rfds);
        rc = select(elf_gems_sockfd+1, &rfds, NULL, NULL, NULL);
        if (rc > 0) {
            if (FD_ISSET(elf_gems_sockfd, &rfds)) {
                rc = recvfrom(elf_gems_sockfd, data, sizeof(data), 0,
                              (struct sockaddr *)&daddr, &daddr_len);
                printf("rc = %d\n", rc);
                if (rc) {
                    msg_hdr = (message_hdr_t *)data;
                    printf("message = %d\n", msg_hdr->cmd);
                    switch (msg_hdr->cmd) {
                        case 0x01:
                            msg_1_hndlr(data);
                            break;
                        case 0x02:
                            msg_2_hndlr(data);
                            break;
                        case 0x03:
                            msg_3_hndlr(data);
                            break;
                        case 0x05:
                            msg_5_hndlr(data);
                            break;
                        case 0x81:
                            msg_81_hndlr(data);
                            break;
                        default:
                            printf("Incorrect %d message\n", msg_hdr->cmd);
                            break;
                    }
                }
            }
        }
    }

    return 0;
}
