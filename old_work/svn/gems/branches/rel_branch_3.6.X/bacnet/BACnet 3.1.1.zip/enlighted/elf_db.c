#include <openssl/md5.h>
#include <unistd.h>
#include "elf.h"

extern uint32_t  g_first_device_instance;
uint32_t         g_max_bacnet_id = 0;
uint32_t         g_bacnet_device_count = 0;
elf_bacnet_db_t *g_bacnet_db = NULL;

static int compare_bacnet_id_sort(const void *s1, const void *s2);
static int compare_bacnet_id_sort(const void *s1, const void *s2)
{
    elf_bacnet_db_t *d1 = (elf_bacnet_db_t *)s1;
    elf_bacnet_db_t *d2 = (elf_bacnet_db_t *)s2;

    return (d1->bacnet_id - d2->bacnet_id);
}

static int compare_bacnet_id_search(const void *key, const void *s);
static int compare_bacnet_id_search(const void *key, const void *s)
{
    elf_bacnet_db_t *d = (elf_bacnet_db_t *)s;

    uint32_t x = *(uint32_t *)key;
    uint32_t y = d->bacnet_id;

    return (x - y);
}

static void *alloc_bacnet_db(void *ptr, uint16_t size)
{
    if ( (ptr = realloc(ptr, size)) == NULL)
    {
        log_printf(LOG_CRIT, "%s:%d - Error allocating memory",
                   __FUNCTION__, __LINE__);
        exit(EXIT_FAILURE);
    }

    return ptr;
}

int init_bacnet_db(void)
{
    g_bacnet_db = NULL;
    g_bacnet_device_count = 0;
    g_max_bacnet_id = g_first_device_instance;
    return 0;
}

int read_bacnet_db(void)
{
    FILE     *fp;
    char      buffer[128];
    char     *ptr = NULL, *tptr = buffer;
    char     *nptr[10] = {NULL};
    uint16_t  count = 0;
    char     *db_file = (char *)elf_get_db_file_config();

    init_bacnet_db();
    if ((fp = fopen(db_file, "r")))
    {
        while (fgets(buffer, sizeof(buffer), fp) != NULL)
        {
            if (buffer[0] == '#' || buffer[0] == '\n' || buffer[0] == '\r') {
                /* Comment line - ignore. */
                continue;
            }
            buffer[strlen(buffer)-1] = 0;

            count = 0;
            while ( (tptr = strtok_r(tptr, ",", &ptr)) != NULL)
            {
                nptr[count++] = tptr;
                tptr = NULL;
            }

            g_bacnet_db = alloc_bacnet_db(g_bacnet_db,
                                          (g_bacnet_device_count+1) * sizeof(elf_bacnet_db_t));
            g_bacnet_db[g_bacnet_device_count].bacnet_id = atol(nptr[0]);
            if (g_max_bacnet_id < g_bacnet_db[g_bacnet_device_count].bacnet_id)
            {
                g_max_bacnet_id = atol(nptr[0])+1;
            }
            g_bacnet_db[g_bacnet_device_count].floor_id = atoi(nptr[1]);
            g_bacnet_db[g_bacnet_device_count].zone_id = atoi(nptr[2]);
            g_bacnet_db[g_bacnet_device_count].zone_type = atoi(nptr[3]);
            g_bacnet_db[g_bacnet_device_count].state = atoi(nptr[4]);
            g_bacnet_db[g_bacnet_device_count].update_ts = 0;
            ++g_bacnet_device_count;
            tptr = buffer;
        }
    }

    return 0;
}

int write_bacnet_db(void)
{
    FILE    *fp;
    uint16_t count = 0;

    if (g_bacnet_device_count == 0) {
        return 0;
    }

    qsort((void *)g_bacnet_db, g_bacnet_device_count,
          sizeof(elf_bacnet_db_t), compare_bacnet_id_sort);

    elf_bacnet_db_t *ptr = g_bacnet_db;
    char            *db_file = (char *)elf_get_db_file_config();

    if ((fp = fopen(db_file, "w+")))
    {
        for (count = 0; count < g_bacnet_device_count; count++, ptr++)
        {
            fprintf(fp,
                    "%u,%u,%u,%d,%d\n",
                    ptr->bacnet_id, ptr->floor_id,
                    ptr->zone_id, ptr->zone_type, ptr->state);
        }

        fclose(fp);

        return 0;
    }

    log_printf(LOG_INFO, "Error=%s", strerror(errno));
    return -1;
}

int add_to_bacnet_db(uint8_t *data)
{
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)data;
    g_bacnet_db = alloc_bacnet_db(g_bacnet_db,
                                  (g_bacnet_device_count+1)*sizeof(elf_bacnet_db_t));
    memcpy((void *)&g_bacnet_db[g_bacnet_device_count], ptr, sizeof(*ptr));
    if (g_bacnet_device_count == 0) {
        g_bacnet_db[g_bacnet_device_count].bacnet_id = g_first_device_instance;
    }
    else {
        ++g_bacnet_db[g_bacnet_device_count].bacnet_id;
    }
    g_max_bacnet_id = g_bacnet_db[g_bacnet_device_count].bacnet_id;
    ++g_bacnet_device_count;
    qsort((void *)g_bacnet_db, g_bacnet_device_count,
          sizeof(elf_bacnet_db_t), compare_bacnet_id_sort);
    return 0;
}

void mark_bacnet_db(void)
{
    uint16_t         count = 0;
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)&g_bacnet_db[0];
    for (count = 0; count < g_bacnet_device_count; count++, ptr++)
    {
        // Mark state as invalid.
        ptr->state = DEVICE_STATE_INVALID;
    }
}

int update_bacnet_db(uint8_t *data)
{
    uint16_t i = 0;

    if(!data) {
        return -1;
    }

    uint32_t device_id;
    // cr00003 - uint8_t  new_entry = 0;
    elf_bacnet_db_t *sptr = NULL;
    elf_bacnet_db_t *zptr = (elf_bacnet_db_t *)data;
    for (i = 0; i < elf_get_device_count(); i++, zptr++)
    {
    	// cr00003 - new_entry = 0;
        if ( (sptr = bsearch(&device_id, g_bacnet_db, g_bacnet_device_count,
                             sizeof(elf_bacnet_db_t),
                             compare_bacnet_id_search)) != NULL)
        {
            // Found the device.
            sptr->state = zptr->state;
        }
    }

    qsort((void *)g_bacnet_db, g_bacnet_device_count,
          sizeof(elf_bacnet_db_t), compare_bacnet_id_sort);

    return 0;
}

void *find_bacnet_id_in_db(uint32_t bacnet_id)
{
    return bsearch(&bacnet_id, g_bacnet_db,
                   g_bacnet_device_count,
                   sizeof(elf_bacnet_db_t), compare_bacnet_id_search);
}

