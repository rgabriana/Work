#ifndef __ELF_OBJECTS_H__
#define __ELF_OBJECTS_H__

#include "bacenum.h"

#define INTERVAL_IN_MINS 5
#define MINUTES_PER_HOUR 60

#define MAX_OBJECT_TYPES       (3) // AI, BI, AV

#define STARTING_ZONES_OBJECT_INDEX     (0)
#define ENDING_ZONES_OBJECT_INDEX       (15)

#define STARTING_SENSORS_OBJECT_INDEX   (16)
#define ENDING_SENSORS_OBJECT_INDEX     (31)

#define MAX_OBJECTS            (100)
// Maximum Objects per type
#define MAX_OBJECTS_PER_TYPE   (20)
// Maximum Supported Object Types per device type (AV, BV, AO etc)
#define MAX_OBJECT_TYPES_PER_DEVICE (64) // 6 bit value from 0 to 63

#define OBJECT_CFG_INDEX       (1)
#define OBJECT_ASSIGNED_INDEX  (2)

#define GET_INDEX_FROM_INSTANCE(oi) ((uint8_t) (oi & 0x3F))
#define GET_ID_FROM_INSTANCE(oi)    ((oi >> 6) & 0x3FFFF)

#define SET_OBJECT_INSTANCE(sid,index) ((sid << 6) | (index))

typedef enum
{
    /* These values need to match the 'index' values in bacnet_objects.cfg */
#ifdef UEM
    ELF_AI_ZONE_MIN_TEMP = 0,
    ELF_AI_ZONE_MAX_TEMP = 1,
    ELF_AI_ZONE_AVG_TEMP = 2,
    ELF_AI_ZONE_SETBACK  = 3,

	ELF_AO_ZONE_SETBACK  = 0,
#else
    ELF_AI_ZONE_DIM_LEVEL_OBJECT = 0,
    ELF_AI_ZONE_BASE_ENERGY_OBJECT,
    ELF_AI_ZONE_USED_ENERGY_OBJECT,
    ELF_AI_ZONE_SAVED_ENERGY_OBJECT,
    ELF_AI_ZONE_OCC_SAVED_ENERGY_OBJECT,
    ELF_AI_ZONE_AMB_SAVED_ENERGY_OBJECT,
    ELF_AI_ZONE_TASK_SAVED_ENERGY_OBJECT,
    ELF_AI_ZONE_MANUAL_SAVED_ENERGY_OBJECT,
    ELF_AI_ZONE_MAX_VALUES,
#endif
} ELF_AI_ZONE_OBJECT_TYPES;

typedef enum
{
    /* These values need to match the values in bacnet_objects.cfg */
    ELF_BI_ZONE_OCCUPANCY_OBJECT = 0,
    ELF_BI_ZONE_MAX_VALUES,
} ELF_BI_ZONE_OBJECT_TYPES;


// Objects at Sensor level
typedef enum
{
    /* These values need to match the values in bacnet_objects.cfg */
    ELF_AV_DIM_LEVEL_OBJECT = 16,
    ELF_AV_MAX_VALUES,
} ELF_AV_OBJECT_TYPES;

typedef enum
{
    /* These values need to match the values in bacnet_objects.cfg */
    ELF_AI_BASE_ENERGY_OBJECT = 16,
    ELF_AI_USED_ENERGY_OBJECT,
    ELF_AI_SAVED_ENERGY_OBJECT,
    ELF_AI_OCC_SAVED_ENERGY_OBJECT,
    ELF_AI_AMB_SAVED_ENERGY_OBJECT,
    ELF_AI_TASK_SAVED_ENERGY_OBJECT,
    ELF_AI_MANUAL_SAVED_ENERGY_OBJECT,
    ELF_AI_MAX_VALUES,
} ELF_AI_OBJECT_TYPES;

typedef enum
{
    /* These values need to match the values in bacnet_objects.cfg */
    ELF_BI_OCCUPANCY_OBJECT = 16,
    ELF_BI_MAX_VALUES,
} ELF_BI_OBJECT_TYPES;

typedef enum elf_device_t
{
    LTG_ZONE_DEVICE_TYPE = 0,
    HVAC_ZONE_DEVICE_TYPE,
    // Add new devices above this line
    MAX_DEVICE_TYPES,
} e_elf_device_t;

typedef enum elf_object_types_t
{
    LTG_ZONE_OBJECT_TYPE = 0,
    SENSOR_OBJECT_TYPE,
    HVAC_ZONE_OBJECT_TYPE,
    // Add new devices above this line
} e_elf_object_types_t;

typedef struct elf_objects
{
    BACNET_OBJECT_TYPE       bacnet_obj_type;
    char                     name[128];
    char                     description[128];
    BACNET_ENGINEERING_UNITS units;
    uint8_t                  cfg_index;      // comes from config file

    // EKH: OBJECT_CFG_INDEX removed, see cr00001
    // uint8_t                  assigned_index; // assigned based on config

    uint8_t                  index_valid;    	// 0 = index not valid, 1 = valid
    e_elf_object_types_t     enl_obj_type;		// hvac-zone, ltg-zone, sensor

    // from BACnet
    BACNET_RELIABILITY Reliability;
    bool Out_Of_Service;
    uint8_t Units;
    float Prior_Value;
    float COV_Increment;
    bool Changed;

    // needed for AO only, one day compact?
    float priority_array[16] ;
    bool  priority_asserted[16] ;
    float relinquish_default ;

} __attribute ((__packed__)) ts_elf_objects_t;
    
typedef struct elf_objects_index
{
	e_elf_object_types_t	enl_obj_type;
    BACNET_OBJECT_TYPE 		bacnet_obj_type;
    uint8_t            valid_obj_count;
    uint8_t            valid_obj_index[MAX_OBJECTS_PER_TYPE]; // list of valid index
} __attribute ((__packed__)) ts_elf_objects_index_t;
    
typedef struct elf_objects_index_list
{
    ts_elf_objects_index_t *index_ptr;
} __attribute ((__packed__)) ts_elf_objects_index_list_t;
    
#endif /* __ELF_OBJECTS_H__ */
