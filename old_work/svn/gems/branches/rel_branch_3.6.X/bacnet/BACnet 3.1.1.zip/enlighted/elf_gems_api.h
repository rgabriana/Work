#ifndef __ELF_GEMS_API_H__
#define __ELF_GEMS_API_H__

//#define GET_FLOOR_LIST_API "https://%s/ems/api/org/floor/list HTTP/1.1"
#include "elf_std.h"

#ifdef UEM
#define GET_FLOOR_LIST_API 		"https://%s/uem/services/hvac/list/floors"
#define GET_AREA_LIST_API  		"https://%s/uem/services/hvac/list/zones/%d"
#define GET_HVAC_STATS_BY_ZONE_API	"https://%s/uem/services/hvac/stats/zone/%d"
#define SET_SETBACK_API				"https://%s/uem/services/hvac/zone/%d/setback/%f/%ld"
#else
#define GET_FLOOR_LIST_API "https://%s/ems/api/org/floor/v1/list HTTP/1.1"
#define GET_SENSOR_LOC_BY_FLOOR_API "https://%s/ems/api/org/fixture/location/list/%d HTTP/1.1"
#define GET_AREA_LIST_API  "https://%s/ems/api/org/area/list/%d HTTP/1.1"
#define GET_SENSORS_LOC_BY_AREA_API "https://%s/ems/api/org/fixture/v1/location/list/area/%d?floorId=%d HTTP/1.1"
#define SET_DIM_SENSOR_BY_ID_API "https://%s/ems/api/org/sensor/op/dim/%s/%d/%d HTTP/1.1"
#define GET_SENSOR_ENERGY_STATS_BY_FLOOR_API "https://%s/ems/api/org/sensor/v1/lastSensorEnergyStats/15min/floor/%d HTTP/1.1"
#define SET_SENSOR_DIM_LEVEL_API "https://%s/ems/api/org/sensor/op/dim/%s/%d/%d HTTP/1.1"
#define GET_SENSOR_DIM_LEVEL_API "https://%s/ems/api/org/sensor/v1/getSensorDimValues HTTP/1.1"
#define GET_FLOOR_AREA_OCC_STATE_API "https://%s/ems/api/org/facility/v1/getOccupancyStateOfFloorAreas/%d HTTP/1.1"
#endif

#define TMP_FILES_PATH     "/tmp"
#define TMP_FILE_PREFIX    "xml"

#define SENSORS_XML             "sensors"
#define AREAS_XML               "areas"
#define FLOORS_XML              "floors"

#ifdef UEM
#define HVAC_STATS_ZONE_XML     "hvac_stats_zone"
#define SET_SETBACK_XML			"setback"
#else
#define SENSORS_LOC_XML         "sensors_loc"
#define SENSORS_ENERGY_XML      "sensors_energy"
#define SET_SENSOR_DIM_XML      "set_sensor_dim_level"
#define SET_SENSOR_DIM_OUT_XML  "set_sensor_dim_level_out"
#define GET_SENSOR_DIM_XML      "get_sensor_dim_level"
#define GET_FLOOR_AREA_OCC_XML  "get_floor_area_occ"
#endif

#ifdef EM
typedef struct sensor
{
    unsigned int  id;
    unsigned char name[256];
    unsigned char mac_address[3]; // we use only last 3 bytes
    unsigned int  x;
    unsigned int  y;
    float          base_energy;
    float          used_energy;
    float          saved_energy;
    float          occ_saved_energy;
    float          amb_saved_energy;
    float          task_saved_energy;
    float          manual_saved_energy;
    unsigned int  occupancy;
    unsigned int  dim_level;
    unsigned int  state; // 0 means invalid, 1 means valid
} s_sensor_t;
#endif
typedef struct oid
{
    unsigned int  type;
    unsigned int  num_oids;
    unsigned int *oid;
} s_oid_t;

typedef struct area
{
    unsigned int   bacnet_id;
    unsigned int   id;
    unsigned int   type;
    char  name[256];
#ifdef UEM
    float	max_temp;
    float	min_temp;
    float	avg_temp;
    float	setback;
#else
    unsigned int   num_sensors;
    s_sensor_t    *s_sensor;
    float          base_energy;
    float          used_energy;
    float          saved_energy;
    float          occ_saved_energy;
    float          amb_saved_energy;
    float          task_saved_energy;
    float          manual_saved_energy;
    unsigned int   occupancy;
    uint32_t       avg_dim_level;
#endif
    unsigned int   num_obj_types;
    s_oid_t       *s_oid;
    unsigned int   state;
} s_area_t;

typedef struct floor
{
    unsigned int   id;
    unsigned char  company_name[256];
    unsigned char  campus_name[256];
    unsigned char  bldg_name[256];
    unsigned char  floor_name[256];
    unsigned int   num_areas;
    s_area_t      *s_area;
} s_floor_t;

typedef struct floor_list
{
    unsigned int  num_floors;
    s_floor_t    *floors;
} s_floor_list_t;

typedef struct zone
{
    unsigned int   	bacnet_id;
    unsigned int   	id;
    char  			name[256];
    char  			company_name[256];
    char  			campus_name[256];
    char  			bldg_name[256];
    char  			floor_name[256];
    unsigned int   	floor_id;
    unsigned int   	type;
#ifdef UEM
    float	max_temp ;
    float 	min_temp ;
    float 	avg_temp ;
    float 	setback ;
#else
    unsigned int   num_sensors;
    float          base_energy;
    float          used_energy;
    float          saved_energy;
    float          occ_saved_energy;
    float          amb_saved_energy;
    float          task_saved_energy;
    float          manual_saved_energy;
    unsigned int   occupancy;
    uint32_t       avg_dim_level;
#endif
    unsigned int   state;
} s_zone_t;

#endif /* __ELF_GEMS_API_H__ */
