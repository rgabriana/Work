#include <sys/ioctl.h>
#include <net/if.h> 
#include <unistd.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/types.h>
#include <pwd.h>
#include <stdarg.h>

#include "elf.h"
#include "elf_gems_api.h"
#include "elf_std.h"

extern elf_config_t elf_bacnet_config;
extern int          g_log_level;

uint32_t            elf_device_count = 0;

uint8_t is_object_instance_valid(uint32_t instance, uint8_t object_type)
{
    uint8_t ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   object_type);

    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if (instance < ltg_zone_obj_count) {
            return 1;
        }
    }
    else if (elf_bacnet_config.mode == SENSORS_ONLY_MODE)
    {
        if (instance < ltg_zone_obj_count) {
            return 0;
        }
        return 1;
    }
    else if ((elf_bacnet_config.mode == ZONE_SENSORS_MODE) ||
             (elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE))
    {
        if (instance < ltg_zone_obj_count) {
            return 1;
        }
        else
        {
            return elf_is_object_index_valid(SENSOR_OBJECT_TYPE, object_type,
                                             GET_INDEX_FROM_INSTANCE(instance));
        }
    }

    return 0;
}

char *elf_convert_mac2str(uint8_t *mac, char *str_value)
{
    uint8_t ln;
    uint8_t hn;
    uint8_t i, value;

    for (i = 0; i < 6; i++)
    {
        value = mac[i];
        ln = value & 0x0F;

        if (ln >= 0 && ln <= 9) {
            str_value[i*2+1] = ln + '0';
        }
        else if (ln >= 10 && ln <= 15) {
            str_value[i*2+1] = ln-10 + 'a';
        }

        hn = ((value >> 4) & 0x0F);

        if (hn >= 0 && hn <= 9) {
            str_value[i*2+0] = hn + '0';
        }
        else if (hn >= 10 && hn <= 15) {
            str_value[i*2+0] = hn-10 + 'a';
        }
    }

    str_value[12] = 0;

    return str_value;
}

void elf_set_device_count(uint32_t count)
{
    elf_device_count = count;
}

uint32_t elf_get_device_count();

uint32_t elf_get_device_count()
{
    return elf_device_count;
}

int elf_create_bacnet_devices(void)
{
    if (Devices)
    {
        free(Devices);
        Devices = NULL;
    }

    // int devcnt = MAX_NUM_DEVICES ;

    log_printf(LOG_INFO, "Max number of device=%d", MAX_NUM_DEVICES);
    Devices = (DEVICE_OBJECT_DATA *)calloc(MAX_NUM_DEVICES,
                                           sizeof(DEVICE_OBJECT_DATA));
    if (!Devices)
    {
        log_printf(LOG_CRIT, "%s:%d - Error allocating memory for bacnet devices", __FUNCTION__, __LINE__);
        return -1;
    }

    return 0;
}

const char *elf_get_version(void)
{
    return ELF_VERSION; // this is coming from Makefile
}

int elf_get_mac_address(unsigned char mac[])
{
    struct ifreq ifr;
    struct ifconf ifc;
    char buf[1024];
    bool success = false;

    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (sock == -1) {
        return 1;
    }

    ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = buf;
    if (ioctl(sock, SIOCGIFCONF, &ifc) == -1) {
        return 2;
    }

    struct ifreq* it = ifc.ifc_req;
    struct ifreq* end = it + (ifc.ifc_len / sizeof(struct ifreq));

    char *interface = (char *)elf_get_db_interface();
    for (; it != end; ++it)
    {
        if (strcmp(it->ifr_name, interface)) {
            continue;
        }

        strcpy(ifr.ifr_name, it->ifr_name);
        if (ioctl(sock, SIOCGIFFLAGS, &ifr) == 0)
        {
            if (! (ifr.ifr_flags & IFF_LOOPBACK)) { // don't count loopback
                if (ioctl(sock, SIOCGIFHWADDR, &ifr) == 0)
                {
                    success = true;
                    break;
                }
            }
        }
    }

    close(sock);

    if (success) {
        memcpy(mac, ifr.ifr_hwaddr.sa_data, 6);
    }
    else
    {
        FILE *fp;
        char mac_buf[32];
        char cmd_buf[128];
        snprintf(cmd_buf, sizeof(cmd_buf),
                 "ifconfig %s | head -1 | awk -F' ' '{print $5}'", interface);
        //fp = popen("ifconfig eth0 | head -1 | awk -F' ' '{print $5}'", "r");
        fp = popen(cmd_buf, "r");
        if (fp) {
            memset(mac_buf, 0, sizeof(mac_buf));
            fread(mac_buf, sizeof(uint8_t), sizeof(mac_buf), fp);
            if (mac_buf[0] != 0)
            {
                sscanf(mac_buf, "%02x:%02x:%02x:%02x:%02x:%02x",
                       (unsigned int *)&ifr.ifr_hwaddr.sa_data[0],
                       (unsigned int *)&ifr.ifr_hwaddr.sa_data[1],
                       (unsigned int *)&ifr.ifr_hwaddr.sa_data[2],
                       (unsigned int *)&ifr.ifr_hwaddr.sa_data[3],
                       (unsigned int *)&ifr.ifr_hwaddr.sa_data[4],
                       (unsigned int *)&ifr.ifr_hwaddr.sa_data[5]);
                memcpy(mac, ifr.ifr_hwaddr.sa_data, 6);
                fclose(fp);
                return 0;
            }
            fclose(fp);
        }
        return 3;
    }

    return 0;
}

ts_elf_objects_t *elf_get_object ( uint16_t obj_type, uint32_t object_instance )
{
	// cr00002 not used, taking out for now -- uint8_t type ;
	uint16_t ourIndex;

	if ( elf_object_instance_to_index(// cr00002 not used, taking out for now -- obj_type,
            object_instance,
			// cr00002 not used, taking out for now -- &type,
            &ourIndex) < 0 ) return NULL ;

	return  elf_get_object_by_type(obj_type, ourIndex, OBJECT_CFG_INDEX);
}

const char *elf_get_object_name(uint16_t obj_type, uint32_t object_instance,
                                char *name)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;
    // cr00002 - uint8_t           type = 0;
    int8_t            rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- obj_type,
                                                        object_instance,
														// cr00002 not used, taking out for now -- &type,
                                                        &index);
    sprintf(name, "%s", "unknown");

    if (rc < 0) {
        return name;
    }

    ptr = elf_get_object_by_type(obj_type, index, OBJECT_CFG_INDEX);
    if (!ptr) {
        return name;
    }

    uint32_t id = elf_get_device_id();
    s_zone_t *zptr = (s_zone_t *)get_zone_data(id);
#ifdef EM
    s_sensor_t *sptr = (s_sensor_t *)get_sensor_data(id, object_instance);
#endif
    if (zptr)
    {
        // Found zone
        const char *fmt = (const char *)elf_get_object_name_format_string(index);
        int         use_default = 1;

        unsigned char name_fmt[512];
        if (fmt)
        {
            char *nptr = (char *)fmt;
            unsigned int i = 0, j = 0;
            memset(name_fmt, 0, sizeof(name_fmt));
            while ((*nptr) && (i < (sizeof(name_fmt)-1)))
            {
                switch (*nptr)
                {
                    case '%':
                    {
                        switch (*(nptr+1))
                        {
                            case 'C':
                            {
                                for (j = 0; (j < strlen((char *)zptr->company_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = zptr->company_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'c':
                            {
                                for (j = 0; (j < strlen((char *)zptr->campus_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = zptr->campus_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'B':
                            {
                                for (j = 0; (j < strlen((char *)zptr->bldg_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = zptr->bldg_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'F':
                            {
                                for (j = 0; (j < strlen((char *)zptr->floor_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = zptr->floor_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'Z':
                            {
                                for (j = 0; (j < strlen((char *)zptr->name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = zptr->name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'P':
                            {
                                for (j = 0; (j < strlen((char *)ptr->name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = ptr->name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'T':
                            {
                                char *t = "LTG";
                                for (j = 0; (j < strlen((char *)t) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = t[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'M':
                            {
                                uint8_t mac[3] = {0};
#ifdef EM
                                if (sptr)
                                {
                                    mac[0] = sptr->mac_address[0];
                                    mac[1] = sptr->mac_address[1];
                                    mac[2] = sptr->mac_address[2];
                                }
#endif
                                char mac_str[9] = {0};
                                snprintf(mac_str, sizeof(mac_str),
                                         "%02hhX:%02hhX:%02hhX",
                                         mac[0], mac[1], mac[2]);
                                for (j = 0; ((j < strlen(mac_str)) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = mac_str[j];
                                }
                                nptr += 2;
                                break;
                            }
                            default:
                            {
                                name_fmt[i++] = *nptr++;
                                break;
                            }
                        }
                        break;
                    }
                    default:
                    {
                        name_fmt[i++] = *nptr++;
                        break;
                    }
                }
            }
            use_default = 0;
        }

        if (use_default)
        {
            sprintf(name, DEFAULT_OBJECT_NAME_FMT_STR,
                    zptr->company_name, zptr->campus_name, zptr->bldg_name,
                    zptr->floor_name, zptr->name, "LTG", ptr->name);
        }
        else {
            strcpy((char *)name, (char *)name_fmt);
        }
        free(zptr);
    }
    log_printf(LOG_INFO, "Object name = %s", name);

    return name;
}

time_t elf_get_current_time(void)
{
    return time(NULL);
}

// todo - replace this
// #define PROCESS_USERNAME    "enlighted"
#define PROCESS_USERNAME    "ed"

int elf_get_my_id(const char *name, int *uid, int *gid)
{
    struct passwd *pwd = NULL;
    if (name == NULL) {
       name = PROCESS_USERNAME;
    }
    pwd = getpwnam(name);
    if (!pwd) {
        return -1;
    }

    *uid = pwd->pw_uid;
    *gid = pwd->pw_gid;

    return 0;
}

void log_printf(int level, const char *fmt, ...)
{
    va_list ap;
    if (level <= g_log_level)
    {
        va_start(ap, fmt);
        vsyslog(level, fmt, ap);
        va_end(ap);
    }
}

