#ifndef __ELF_FUNCTIONS_H__
#define __ELF_FUNCTIONS_H__

#include "elf_std.h"

extern int elf_get_av_object_count(void);
extern const char *elf_get_av_description(uint32_t object_instance);
extern const char *elf_get_av_name(uint32_t object_instance, char *name);
extern BACNET_ENGINEERING_UNITS elf_get_av_units(uint32_t object_instance);
BACNET_ENGINEERING_UNITS elf_get_ao_units(uint32_t object_instance);
extern float elf_get_av_present_value(uint32_t object_instance);

extern int elf_get_bv_object_count(void);
extern const char *elf_get_bv_description(uint32_t object_instance);
extern const char *elf_get_bv_name(uint32_t object_instance, char *name);
extern BACNET_BINARY_PV elf_get_bv_present_value(uint32_t object_instance);

extern int elf_get_ao_object_count(void);
extern const char *elf_get_ao_description(uint32_t object_instance);
extern const char *elf_get_ao_name(uint32_t object_instance, char *name);
extern float elf_get_ao_present_value(uint32_t object_instance);
extern int elf_set_ao_present_value(ts_elf_objects_t *currentObject, float value);
extern int elf_set_av_present_value(uint32_t object_instance, float value);

extern uint32_t elf_get_device_count();

extern int elf_init_sensors(uint8_t *data);
extern int elf_read_config_file(const char *config_file);

extern const char *elf_get_device_object_name(char *name, int name_len);
extern const char *elf_get_device_app_sw_version(char *name, int name_len);
extern int elf_set_device_system_status(void);
extern int elf_get_config(int cfg_type);

extern void elf_set_device_count(uint32_t count);
extern int elf_create_bacnet_devices(void);
extern int32_t elf_get_gems_device_id();
extern const char *elf_get_db_file_config(void);
extern const char *elf_get_db_gems_ip_address_config(void);
extern const char *elf_get_db_proxy_ip_address_config(void);
extern const char *elf_get_db_bbmd_peer_ip_address_config(void);
extern const char *elf_get_db_interface(void);
extern void elf_init_config(void);

extern void elf_devices_setup(uint8_t send_i_am);

extern const char *elf_get_gems_app_sw_version(uint32_t index, char *name,
                                               int name_len); 
extern const char *elf_get_version(void);
extern bool elf_valid_object_instance(BACNET_OBJECT_TYPE bacType, uint32_t instance);
extern int elf_get_mac_address(unsigned char mac[]);
extern void elf_get_device_mac_address(uint8_t *mac_address);
extern bool elf_is_object_index_valid(uint8_t enl_obj_type,
                                      uint16_t object_type, uint8_t index);
extern uint16_t elf_get_number_of_objects(uint8_t enl_obj_type,
                                          uint16_t bacnet_object_type);
extern ts_elf_objects_t *elf_get_object_by_type_instance(BACNET_OBJECT_TYPE bacnet_object_type, uint32_t bacnet_object_instance );
extern ts_elf_objects_t *elf_get_object_by_type(BACNET_OBJECT_TYPE bacnet_object_type, uint8_t index, uint8_t index_type);
extern int8_t   elf_objects_setup(void);

extern int   init_bacnet_db(void);
extern int   read_bacnet_db(void);
extern int   write_bacnet_db(void);
extern int   add_to_bacnet_db(uint8_t *data);
extern void  mark_bacnet_db(void);
extern void *find_bacnet_id_in_db(uint32_t bacnet_id);
extern int   update_bacnet_db(uint8_t *data);
extern void  create_bacnet_db_iterators(void);

extern uint32_t elf_get_device_id(void);
extern int32_t elf_bacnet_id_to_gems_device_id(uint32_t bacnet_device_id);
extern int32_t elf_gems_id_to_bacnet_id(uint32_t gems_device_id);
extern int8_t elf_index_to_object_instance(unsigned int index,
                                           uint8_t object_type,
                                           uint32_t *object_instance);
extern int8_t elf_object_instance_to_index(// cr00002 not used, taking out for now -- BACNET_OBJECT_TYPE object_type,
                                           uint32_t object_instance,
										   // cr00002 not used, taking out for now -- uint8_t *device_type,
                                           uint16_t *index);				// changed this to uint8_t because that is how it is stored in the tables
// cr00002 not used, taking out for now -- extern e_elf_device_t  elf_get_device_type(void);
extern uint16_t elf_get_object_count(uint8_t object_type);
extern int32_t  elf_get_gems_device_id(void);
extern char    *elf_convert_mac2str(uint8_t *mac, char *str_value);

extern ts_elf_objects_t *elf_get_object ( uint16_t obj_type, uint32_t object_instance ) ;
extern const char *elf_get_object_name(uint16_t obj_type,
                                       uint32_t object_instance, char *name);
extern const char *elf_get_device_name(uint16_t gems_device_id, char *name);
extern const char *elf_get_objects_file(void);
extern const char *elf_get_msi_name(uint32_t object_instance, char *name);
extern const char *elf_get_msi_description(uint32_t object_instance);
extern uint32_t elf_get_msi_present_value(uint32_t object_instance);
extern uint8_t elf_get_msi_state_count(uint32_t object_instance);
extern char *elf_get_msi_state_text(uint32_t object_instance,
                                    uint32_t state_index, char *state_text);
extern time_t elf_get_current_time(void);
extern int init_hvac_zone_devices(void);
extern void get_mac_address(uint32_t bacnet_id, uint8_t *mac);
extern int16_t elf_get_object_cfg_index(uint16_t object_type, uint8_t index);
extern int elf_get_my_id(const char *name, int *uid, int *gid);

extern void elf_update_timer_init(void);
extern void elf_update_timer_handler(void);

extern int   sync_data_from_em(void);
extern int   get_num_sensors_per_zone(unsigned int bacnet_id);
extern void *get_zone_data(unsigned int bacnet_id);
extern void *get_sensor_data(unsigned int bacnet_id, unsigned int object_instance);
extern void *get_zone_oids(unsigned int bacnet_id, unsigned int *num_obj_types);

extern const char *elf_get_device_name_format_string(void);
extern const char *elf_get_object_name_format_string(uint8_t index);

extern const char *elf_get_bi_name(uint32_t object_instance, char *name);
extern const char *elf_get_bi_description(uint32_t object_instance);
extern BACNET_BINARY_PV elf_get_bi_present_value(uint32_t object_instance);

extern const char *elf_get_ai_name(uint32_t object_instance, char *name);
extern const char *elf_get_ai_description(uint32_t object_instance);
extern BACNET_ENGINEERING_UNITS elf_get_ai_units(uint32_t object_instance);
extern float elf_get_ai_present_value(uint32_t object_instance);

#ifdef UEM
extern const char *elf_get_rest_username(void);
extern const char *elf_get_rest_password(void);
#else
extern const char *elf_get_rest_api_key(void);
extern const char *elf_get_rest_api_secret(void);
uint8_t get_auth_token(const char *ts, uint8_t *token) ;
#endif

#ifdef UEM
extern void set_setback(unsigned int bacnet_device_instance,
                                   float value);
#else
extern int8_t set_sensor_dim_level(unsigned int bacnet_id,
                                   unsigned int object_instance,
                                   unsigned int value);
extern int8_t get_sensor_dim_level(unsigned int bacnet_id,
                                   unsigned int object_instance);
void elf_update_areas(void);
#endif // UEM


extern void log_printf(int level, const char *fmt, ...);
extern const char *elf_get_log_level(void);
extern uint8_t is_object_instance_valid(uint32_t instance, uint8_t object_type);

#endif /* __ELF_FUNCTIONS_H__ */
