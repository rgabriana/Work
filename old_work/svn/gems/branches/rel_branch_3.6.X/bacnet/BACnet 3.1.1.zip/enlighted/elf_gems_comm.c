#include "elf.h"
#include <sys/time.h>
#include <pthread.h>
#include "elf_xml_parse.h"
#include "elf_gems_api.h"
#include "elf_std.h"
#include "elf_functions.h"

#define REQ_TYPE_POST  (1)
#define REQ_TYPE_GET   (2)

#ifdef EM
typedef struct area_occ
{
    int id;
    int occupancy;
} s_area_occ_t;
#endif

extern uint8_t get_auth_token(const char *ts, uint8_t *token);

s_floor_list_t *g_floor_list;

static const char *create_url_headers(char *header, int content_type, int len);

unsigned int obj_types[MAX_OBJECT_TYPES] =
{
    OBJECT_ANALOG_INPUT,
    OBJECT_BINARY_INPUT,
    OBJECT_ANALOG_VALUE,
};

static const char *create_url_headers(char *header, int content_type, int len)
{
#ifdef UEM
    int count = 0;
    count += snprintf(header, len,
                      "-u %s:%s -c cookie.txt -H \"%s\"",
					  elf_get_rest_username(),
					  elf_get_rest_password(),
                      "Accept: application/xml");
#else
    char    ts[32];
    uint8_t auth_token[41];

    memset(auth_token, 0, sizeof(auth_token));

    time_t now = time(NULL);
    snprintf(ts, sizeof(ts)-1, "%lu", now);
    get_auth_token(ts, auth_token);

    int count = 0;
    count += snprintf(header, len,
                      "-H \"%s %s\" -H \"%s %s\" -H \"%s %s\" -H \"%s\"",
                      "ApiKey: ", elf_get_rest_api_key(),
                      "Authorization: ", auth_token,
                      "ts: ", ts,
                      "Accept: application/xml");
#endif

    if (content_type)
    {
        count += snprintf(header+count, len - count,
                          " -H \"%s\"", "Content-Type: application/xml");
    }
    return header;
}

#ifdef UEM
static const char *create_url_headers_write(char *header, int content_type, int len)
{
#ifdef UEM
    int count = 0;
    count += snprintf(header, len,
                      "-u %s:%s -c cookie.txt ",
					  elf_get_rest_username(),
					  elf_get_rest_password()
                      );
#else
    char    ts[32];
    uint8_t auth_token[41];

    memset(auth_token, 0, sizeof(auth_token));

    time_t now = time(NULL);
    snprintf(ts, sizeof(ts)-1, "%lu", now);
    get_auth_token(ts, auth_token);

    int count = 0;
    count += snprintf(header, len,
                      "-H \"%s %s\" -H \"%s %s\" -H \"%s %s\" -H \"%s\"",
                      "ApiKey: ", elf_get_rest_api_key(),
                      "Authorization: ", auth_token,
                      "ts: ", ts,
                      "Accept: application/xml");
#endif

    if (content_type)
    {
        count += snprintf(header+count, len - count,
                          " -H \"%s\"", "Content-Type: application/xml");
    }
    return header;
}
#endif // UEM

#ifdef UEM
static void send_curl_message_write(uint8_t req_type, const char *url,
                                 uint8_t redirect_output, const char *ifile,
                                 const char *ofile)
{
    char cmd[1024];
    char req_headers[1024];
    char redirect_str[1024];
    // int  rc = 0;

    // Setup request headers.
    create_url_headers_write(req_headers, 1, sizeof(req_headers));

    // Forcing this to be 1 always
    redirect_output = 1;

    if (redirect_output)
    {
        snprintf(redirect_str, sizeof(redirect_str), " > %s", ofile);
    }
    else
    {
        // empty string
        snprintf(redirect_str, sizeof(redirect_str), " ");
    }

        // remove any existing file.
        unlink(ofile);

        // setup curl command
        if (req_type == REQ_TYPE_POST)
        {
            sprintf(cmd, "curl --proxy localhost:8888 -s %s -X POST -d @%s -k %s %s",
                    req_headers, ifile, url, redirect_str);
        }
        else
        {
            if (redirect_output)
            {
                sprintf(cmd, "curl --proxy localhost:8888 -s --get %s -k %s %s",
                        req_headers, url, redirect_str);
            }
            else
            {
                sprintf(cmd, "curl --proxy localhost:8888 -s --get %s -o %s -k %s %s",
                        req_headers, ofile, url, redirect_str);
            }
        }

        log_printf(LOG_INFO, "cmd=%s", cmd);

        // execute curl command
        printf("cmd = %s\n", cmd);

        if (system(cmd) < 0)
        {
            log_printf(LOG_CRIT, "In %s: can't execute command %s!\n",
                       __func__, cmd);
            exit(EXIT_FAILURE);
        }
    }
#endif


static uint8_t send_curl_message(uint8_t req_type, const char *url,
                                 uint8_t redirect_output, const char *ifile,
                                 const char *ofile)
{
    char cmd[1024];
    char req_headers[1024];
    char redirect_str[1024];
    char proxy_str[1024] ;
    int  rc = 0;

    // Setup request headers. 
    create_url_headers(req_headers, 1, sizeof(req_headers));

    // Forcing this to be 1 always
    redirect_output = 1;

    if (redirect_output)
    {
        snprintf(redirect_str, sizeof(redirect_str), " > %s", ofile);
    }
    else
    {
        // empty string
        snprintf(redirect_str, sizeof(redirect_str), " ");
    }


    if ( strlen ( elf_get_db_proxy_ip_address_config() ) == 0 )
    {
    	snprintf( proxy_str, sizeof(proxy_str), " " ) ;
    }
    else
    {
    	snprintf( proxy_str, sizeof(proxy_str), "--proxy %s", elf_get_db_proxy_ip_address_config() ) ;
    }


    uint8_t attempts = 0;
    do
    {
        log_printf(LOG_INFO, "%s:%d attempts=%d", __FUNCTION__, __LINE__, attempts);
        // remove any existing file.
        unlink(ofile);

        // setup curl command
        if (req_type == REQ_TYPE_POST)
        {
            sprintf(cmd, "curl %s-s %s -X POST -d @%s -k %s %s",
            		proxy_str,
                    req_headers, ifile, url, redirect_str);
        }
        else
        {
            if (redirect_output)
            {
                sprintf(cmd, "curl %s -s --get %s -k %s %s",
                		proxy_str,
                        req_headers, url, redirect_str);
            }
            else
            {
                sprintf(cmd, "curl %s -s --get %s -o %s -k %s %s",
                		proxy_str,
						req_headers, ofile, url, redirect_str);
            }
        }

        log_printf(LOG_INFO, "cmd=%s", cmd);

        // execute curl command
        printf("cmd = %s\n", cmd);

        if (system(cmd) < 0)
        {
            log_printf(LOG_CRIT, "In %s: can't execute command %s!\n",
                       __func__, cmd);
            exit(EXIT_FAILURE);
        }

        // curl command executed successfully.
        // the output from this command will be in the output file passed in as
        // ofile to this function.
        FILE *fp = fopen(ofile, "r");
        if (fp)
        {
            char        *xml = NULL;
            struct stat  st;
            if (!stat(ofile, &st))
            {
                if (st.st_size != 0)
                {
                    xml = calloc(1, st.st_size+1); // +1 for null termination
                    if (!xml)
                    {
                        log_printf(LOG_CRIT,
                                   "In %s: can't allocate memory for xml data!\n",
                                   __func__);
                        exit(EXIT_FAILURE);
                    }

                    int count = 0;
                    while (!feof(fp))
                    {
                        count += fread(xml+count, 1, 1, fp);
                    }

                    int num_responses = 0;
                    xml_parse_ctx_t x;

                    x.xml_buf = xml;
                    x.xml_xpath = "html/head";
                    parse_xml(&x);
                    num_responses = x.num_results;
                    if (num_responses == 1)
                    {
                        // we should not get <html>...</html>
                        rc = -1;
                        log_printf(LOG_CRIT, "In %s: got html/head response!\n",
                                   __func__);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);
                    free(xml);
                }
            }
            else
            {
                log_printf(LOG_CRIT, "In %s: can't stat file %s\n",
                            __func__, ofile);
                exit(EXIT_FAILURE);
            }
            fclose(fp);
        }
        else
        {
            log_printf(LOG_CRIT, "In %s: can't open file %s\n", __func__, ofile);
            exit(EXIT_FAILURE);
        }
    } while ((rc != 0) && (attempts++ < 3));

    return rc;
}

#ifdef EM
static int compare_sensor_id_sort(const void *s1, const void *s2);
static int compare_sensor_id_sort(const void *s1, const void *s2)
{
    s_sensor_t *d1 = (s_sensor_t *)s1;
    s_sensor_t *d2 = (s_sensor_t *)s2;

    return (d1->id - d2->id);
}

static int compare_sensor_id_search(const void *key, const void *s);
static int compare_sensor_id_search(const void *key, const void *s)
{
    s_sensor_t *d = (s_sensor_t *)s;

    unsigned int x = *(unsigned int *)key;
    unsigned int y = d->id;

    return (x - y);
}

#ifdef EM
void elf_update_areas(void)
{
    // int  rc = 0;
    char ofile[256] = {0};
    char url[1024] = {0};

    if (g_floor_list)
    {
        int i, area_id, floor_id ; // err,
        for (i = 0; i < g_floor_list->num_floors; i++)
        {
            floor_id = g_floor_list->floors[i].id;
            snprintf(url, sizeof(url), GET_FLOOR_AREA_OCC_STATE_API,
                     elf_get_db_gems_ip_address_config(), floor_id);
            snprintf(ofile, sizeof(ofile), "%s/%s_%d.%s",
                     TMP_FILES_PATH, GET_FLOOR_AREA_OCC_XML,
                     floor_id, TMP_FILE_PREFIX);

            // rc =
            		send_curl_message(REQ_TYPE_GET, url, true, NULL, ofile);
            FILE *fp = fopen(ofile, "r");
            if (fp)
            {
                char        *xml = NULL;
                struct stat  st;
                xml_parse_ctx_t x;
                if (!stat(ofile, &st))  
                {
                    if (st.st_size != 0)
                    {
                        xml = calloc(1, st.st_size+1); // +1 for null termination
                        if (!xml)
                        {
                            log_printf(LOG_CRIT,
                                      "In %s: can't allocate memory for xml data!\n", __func__);
                            exit(EXIT_FAILURE);
                        }

                        int count = 0;
                        while (!feof(fp))
                        {
                            count += fread(xml+count, 1, 1, fp);
                        }

                        // Get number of areas
                        int num_areas, k = 0;
                        x.xml_buf = xml;
                        x.xml_xpath = "areas/area";
                        // err =
                        parse_xml(&x);
                        num_areas = x.num_results;

                        // Free allocated buffer
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);

                        s_area_occ_t *p_area_occ = (s_area_occ_t *)calloc(num_areas, sizeof(s_area_occ_t));
                        if (!p_area_occ)
                        {
                            log_printf(LOG_CRIT,
                                      "In %s: can't allocate memory for area occupancy data!\n", __func__);
                            exit(EXIT_FAILURE);
                        }

                        // Get the id of area
                        x.xml_buf = xml;
                        x.xml_xpath = "areas/area/id";
                        // err =
                        parse_xml(&x);
                        for (k = 0; k < num_areas; k++)
                        {
                            p_area_occ[k].id = atoi(x.results[k]);
                        }
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);
    
                        // Get the occupancy of area
                        x.xml_buf = xml;
                        x.xml_xpath = "areas/area/occupancyState";
                        // err =
                        parse_xml(&x);

                        // Get occupancy state for the area
                        for (k = 0; k < num_areas; k++)
                        {
                            int l = 0;
                            for (l = 0; l < g_floor_list->floors[i].num_areas; l++)
                            {
                                s_area_t *p_area = (s_area_t *)&g_floor_list->floors[i].s_area[l];
                                if (p_area)
                                {
                                    area_id = p_area->id;
                                    if (area_id == p_area_occ[k].id)
                                    {
                                        p_area->occupancy = atoi(x.results[k]);
                                        log_printf(LOG_INFO, "OCC=%d",
                                                   p_area->occupancy);
                                        break;
                                    }
                                }
                            }
                        }

                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);
                    }
                }
            }
        }
    }
}
#endif

int8_t set_sensor_dim_level(unsigned int bacnet_id,
                            unsigned int object_instance, unsigned int value)
{
    int  rc = 0;
    char ifile[256] = {0};
    char ofile[256] = {0};

    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)find_bacnet_id_in_db(bacnet_id);
    if (!ptr) {
        return -1;
    }

    int id = GET_ID_FROM_INSTANCE(object_instance);
  
    char  cmd[1024] = {0};
    char  url[1024] = {0};

    snprintf(ifile, sizeof(ifile), "%s/%s.%s", TMP_FILES_PATH,
             SET_SENSOR_DIM_XML, TMP_FILE_PREFIX);

    snprintf(cmd, sizeof(cmd),
             "echo \"<sensors><sensor><id>%d</id></sensor></sensors>\" > %s",
             id, ifile);
    if (system(cmd) < 0)
    {
        log_printf(LOG_CRIT, "In %s: can't execute command %s!\n",
                   __func__, cmd);
        exit(EXIT_FAILURE);
    }

    snprintf(url, sizeof(url), SET_SENSOR_DIM_LEVEL_API,
             elf_get_db_gems_ip_address_config(), "abs", (int)value, 60);

    snprintf(ofile, sizeof(ofile), "%s/%s.%s", TMP_FILES_PATH,
             SET_SENSOR_DIM_OUT_XML, TMP_FILE_PREFIX);

    rc = send_curl_message(REQ_TYPE_POST, url, true, ifile, ofile);
    return rc;
}
#endif

#ifdef UEM
// Currently only one setback per device (zone).
void set_setback(unsigned int bacnet_device_instance, float value)
{
    char ifile[256] = {0};
    char ofile[256] = {0};

    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)find_bacnet_id_in_db(bacnet_device_instance);
    if (!ptr) {
        return ;
    }

    int id = ptr->zone_id ; // GET_ID_FROM_INSTANCE(object_instance);

    // char  cmd[1024] = {0};
    char  url[1024] = {0};

    snprintf(ifile, sizeof(ifile), "%s/%s_if.%s", TMP_FILES_PATH,
             SET_SETBACK_XML, TMP_FILE_PREFIX);

    long int timestamp = 323434l;	// todo, fetch this

    snprintf(url, sizeof(url), SET_SETBACK_API,
             elf_get_db_gems_ip_address_config(), id, value, timestamp );

    snprintf(ofile, sizeof(ofile), "%s/%s_of.%s", TMP_FILES_PATH,
             SET_SETBACK_XML, TMP_FILE_PREFIX);

    send_curl_message_write(REQ_TYPE_POST, url, true, ifile, ofile);
}
#endif // UEM


#ifdef EM
int8_t get_sensor_dim_level(unsigned int bacnet_id,
                            unsigned int object_instance)
{
    char url[1024];
    char ifile[256];
    char ofile[256];
    int  rc = 0;
  
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)find_bacnet_id_in_db(bacnet_id);
    if (!ptr) {
        return -1;
    }

    int id = GET_ID_FROM_INSTANCE(object_instance);
    snprintf(url, sizeof(url), GET_SENSOR_DIM_LEVEL_API,
             elf_get_db_gems_ip_address_config());

    snprintf(ifile, sizeof(ifile), "%s/%s.%s", TMP_FILES_PATH,
             SET_SENSOR_DIM_XML, TMP_FILE_PREFIX);

    char cmd[1024] = {0};
    snprintf(cmd, sizeof(cmd),
             "echo \"<sensors><sensor><id>%d</id></sensor></sensors>\" > %s",
             id, ifile);
    if (system(cmd) < 0)
    {
        log_printf(LOG_CRIT, "In %s: can't exectue command %s!\n",
                   __func__, cmd);
        exit(EXIT_FAILURE);
    }

    snprintf(ofile, sizeof(ofile), "%s/%s.%s", TMP_FILES_PATH,
             GET_SENSOR_DIM_XML, TMP_FILE_PREFIX);
    rc = send_curl_message(REQ_TYPE_POST, url, true, ifile, ofile);

    FILE *fp = fopen(ofile, "r");
    if (fp)
    {
        char        *xml = NULL;
        struct stat  st;
        if (!stat(ofile, &st))
        {
            if (st.st_size != 0)
            {
                xml = calloc(1, st.st_size+1); // +1 for null termination
                if (!xml)
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for xml data!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }

                int count = 0;
                while (!feof(fp))
                {
                    count += fread(xml+count, 1, 1, fp);
                }

                int num_responses = 0;
                xml_parse_ctx_t x;

                x.xml_buf = xml;
                x.xml_xpath = "sensors/Sensor/dimLevel";
                parse_xml(&x);
                num_responses = x.num_results;
                if (num_responses != 1) {
                    rc = -1;
                }
                else {
                    rc = atoi(x.results[0]);
                }
                free(x.results);
                roxml_release(RELEASE_ALL);
                roxml_close(x.root);
            }
        }
        else
        {
            log_printf(LOG_CRIT, "In %s: can't stat file %s\n",
                        __func__, ofile);
            exit(EXIT_FAILURE);
        }
        fclose(fp);
    }
    else
    {
        log_printf(LOG_CRIT, "In %s: can't open file %s\n", __func__, ofile);
        exit(EXIT_FAILURE);
    }
    return rc;
}
#endif

void *get_zone_oids(unsigned int bacnet_id, unsigned int *num_obj_types)
{
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)find_bacnet_id_in_db(bacnet_id);
    if (!ptr)
    {
        return NULL;
    }

    int i, j;

    *num_obj_types = 0;
    for (i = 0; i < g_floor_list->num_floors; i++)
    {
        if (ptr->floor_id != g_floor_list->floors[i].id) {
            continue;
        }
        for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
        {
            if (ptr->zone_id == g_floor_list->floors[i].s_area[j].id)
            {
                *num_obj_types = g_floor_list->floors[i].s_area[j].num_obj_types;
                return g_floor_list->floors[i].s_area[j].s_oid;
            }
        }
    }

    return NULL;
}

#ifdef EM
void *get_sensor_data(unsigned int bacnet_id, unsigned int object_instance)
{
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)find_bacnet_id_in_db(bacnet_id);
    if (!ptr)
    {
        return NULL;
    }

    s_sensor_t *sptr = NULL;
    int i, j;
    int id = (object_instance >> 6) & 0xFFFF;

    for (i = 0; i < g_floor_list->num_floors; i++)
    {
        if (ptr->floor_id != g_floor_list->floors[i].id) {
            continue;
        }
        for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
        {
            if (ptr->zone_id != g_floor_list->floors[i].s_area[j].id) {
                continue;
            }
            qsort((void *)&g_floor_list->floors[i].s_area[j].s_sensor[0],
                  g_floor_list->floors[i].s_area[j].num_sensors,
                  sizeof(s_sensor_t),
                  compare_sensor_id_sort);
            if ((sptr = bsearch(&id,
                                &g_floor_list->floors[i].s_area[j].s_sensor[0],
                                g_floor_list->floors[i].s_area[j].num_sensors,
                                sizeof(s_sensor_t),
                                compare_sensor_id_search)) != NULL)
            {
                // Found sensor that matches the object instance.
                break;
            }
        }
    }

    return sptr;
}
#endif

#ifdef EM
int get_num_sensors_per_zone(unsigned int bacnet_id)
{
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)find_bacnet_id_in_db(bacnet_id);
    if (!ptr)
    {
        return 0;
    }

    int i, j;
    for (i = 0; i < g_floor_list->num_floors; i++)
    {
        if (ptr->floor_id != g_floor_list->floors[i].id) {
            continue;
        }
        for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
        {
            if (ptr->zone_id != g_floor_list->floors[i].s_area[j].id) {
                continue;
            }
            return g_floor_list->floors[i].s_area[j].num_sensors;
        }
    }

    return 0;
}
#endif

void *get_zone_data(unsigned int bacnet_id)
{
    elf_bacnet_db_t *ptr = (elf_bacnet_db_t *)find_bacnet_id_in_db(bacnet_id);
    if (!ptr)
    {
        return NULL;
    }

    int i, j;
    unsigned int found_zone = 0;
    for (i = 0; i < g_floor_list->num_floors; i++)
    {
        if (ptr->floor_id != g_floor_list->floors[i].id) {
            continue;
        }
        for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
        {
            if (ptr->zone_id == g_floor_list->floors[i].s_area[j].id)
            {
                found_zone = 1;
                break;
            }
        }
        if (found_zone) {
            break;
        }
    }

    s_zone_t *zptr = NULL;
    if (found_zone)
    {
        zptr = calloc(1, sizeof(s_zone_t));
        if (zptr)
        {
            zptr->bacnet_id = bacnet_id;
            zptr->id = g_floor_list->floors[i].s_area[j].id;
            strcpy((char *)zptr->name, (char *)&g_floor_list->floors[i].s_area[j].name);
            strcpy((char *)zptr->company_name, (char *)g_floor_list->floors[i].company_name);
            strcpy((char *)zptr->campus_name, (char *)g_floor_list->floors[i].campus_name);
            strcpy((char *)zptr->bldg_name, (char *)g_floor_list->floors[i].bldg_name);
            strcpy((char *)zptr->floor_name, (char *)g_floor_list->floors[i].floor_name);
            zptr->floor_id = g_floor_list->floors[i].id;
            zptr->type = g_floor_list->floors[i].s_area[j].type;
            zptr->state = g_floor_list->floors[i].s_area[j].state;
#ifdef UEM
            zptr->min_temp = g_floor_list->floors[i].s_area[j].min_temp ;
            zptr->max_temp = g_floor_list->floors[i].s_area[j].max_temp ;
            zptr->avg_temp = g_floor_list->floors[i].s_area[j].avg_temp ;
            zptr->setback = g_floor_list->floors[i].s_area[j].setback ;
#else
            zptr->num_sensors = g_floor_list->floors[i].s_area[j].num_sensors;
#ifdef EM
            zptr->state = g_floor_list->floors[i].s_area[j].state;
#endif            
            zptr->base_energy = g_floor_list->floors[i].s_area[j].base_energy;
            zptr->used_energy = g_floor_list->floors[i].s_area[j].used_energy;
            zptr->saved_energy = g_floor_list->floors[i].s_area[j].saved_energy;
            zptr->occ_saved_energy = g_floor_list->floors[i].s_area[j].occ_saved_energy;
            zptr->amb_saved_energy = g_floor_list->floors[i].s_area[j].amb_saved_energy;
            zptr->task_saved_energy = g_floor_list->floors[i].s_area[j].task_saved_energy;
            zptr->manual_saved_energy = g_floor_list->floors[i].s_area[j].manual_saved_energy;
            zptr->avg_dim_level = g_floor_list->floors[i].s_area[j].avg_dim_level;
            zptr->occupancy = g_floor_list->floors[i].s_area[j].occupancy;
#endif
        }
    }
    return zptr;
}

#ifdef UEM
static int get_hvac_stats_per_zone(int zone_id)
{
    // int   rc = 0;
    char  url[1024];
    char  ofile[256] = {0};

    snprintf(url, sizeof(url), GET_HVAC_STATS_BY_ZONE_API,
             elf_get_db_gems_ip_address_config(), zone_id);

    snprintf(ofile, sizeof(ofile), "%s/%s_%d.%s", TMP_FILES_PATH,
             HVAC_STATS_ZONE_XML, zone_id, TMP_FILE_PREFIX);

    // rc =
    send_curl_message(REQ_TYPE_GET, url, true, NULL, ofile);

    FILE *fp = fopen(ofile, "r");
    if (fp)
    {
        char        *xml = NULL;
        struct stat  st;
        if (!stat(ofile, &st))
        {
            if (st.st_size != 0)
            {
                xml = calloc(1, st.st_size+1); // +1 for null termination
                if (!xml)
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for xml data!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }

                int count = 0;
                while (!feof(fp))
                {
                    count += fread(xml+count, 1, 1, fp);
                }

                // int err, i, j, k,
                int i, zone ;
                // int num_sensors = 0;
                xml_parse_ctx_t x;
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                	for(zone=0;zone< g_floor_list->floors[i].num_areas; zone++)
                	{
                		if ( g_floor_list->floors[i].s_area[zone].id == zone_id )
                		{
                			x.xml_buf = xml ;
                			x.xml_xpath = "zone/maxTemp";
                			// err =
                			parse_xml(&x);
                			if ( x.num_results )
                			{
                				g_floor_list->floors[i].s_area[zone].max_temp = atof(x.results[0]);
                			}
                			// todo - do we really have to do this each time?
                			free(x.results);
                			roxml_release(RELEASE_ALL);
                			roxml_close(x.root);

                			x.xml_buf = xml ;
                			x.xml_xpath = "zone/minTemp";
                			// err =
                			parse_xml(&x);
                			if ( x.num_results )
                			{
                				g_floor_list->floors[i].s_area[zone].min_temp = atof(x.results[0]);
                			}
                			// todo - do we really have to do this each time?
                			free(x.results);
                			roxml_release(RELEASE_ALL);
                			roxml_close(x.root);

                			x.xml_buf = xml ;
                			x.xml_xpath = "zone/avgTemp";
                			// err =
                			parse_xml(&x);
                			if ( x.num_results )
                			{
                				g_floor_list->floors[i].s_area[zone].avg_temp = atof(x.results[0]);
                			}
                			// todo - do we really have to do this each time?
                			free(x.results);
                			roxml_release(RELEASE_ALL);
                			roxml_close(x.root);

                			x.xml_buf = xml ;
                			x.xml_xpath = "zone/setback";
                			// err =
                			parse_xml(&x);
                			if ( x.num_results )
                			{
                				g_floor_list->floors[i].s_area[zone].setback = atof(x.results[0]);
                			}
                			// todo - do we really have to do this each time?
                			free(x.results);
                			roxml_release(RELEASE_ALL);
                			roxml_close(x.root);
                		}
                	}
                }
                free ( xml ) ;
            }
        }
        else
        {
            log_printf(LOG_CRIT, "In %s: can't stat file %s\n",
                        __func__, ofile);
            exit(EXIT_FAILURE);
        }
        fclose(fp);
    }
    else
    {
        log_printf(LOG_CRIT, "In %s: can't open file %s\n", __func__, ofile);
        exit(EXIT_FAILURE);
    }

    return 0;
}
#endif


#ifdef EM
static int get_sensors_energy_stats_per_floor(int floor_id)
{
    // int   rc = 0;
    char  url[1024];
    char  ofile[256] = {0};

    snprintf(url, sizeof(url), GET_SENSOR_ENERGY_STATS_BY_FLOOR_API,
             elf_get_db_gems_ip_address_config(), floor_id);

    snprintf(ofile, sizeof(ofile), "%s/%s_%d.%s", TMP_FILES_PATH,
             SENSORS_ENERGY_XML, floor_id, TMP_FILE_PREFIX);

    // rc =
    send_curl_message(REQ_TYPE_GET, url, true, NULL, ofile);

    FILE *fp = fopen(ofile, "r");
    if (fp)
    {
        char        *xml = NULL;
        struct stat  st;
        if (!stat(ofile, &st))  
        {
            if (st.st_size != 0)
            {
                xml = calloc(1, st.st_size+1); // +1 for null termination
                if (!xml)
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for xml data!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }

                int count = 0;
                while (!feof(fp))
                {
                    count += fread(xml+count, 1, 1, fp);
                }

                // int err
				int i, j, k;
                int num_sensors = 0;
                xml_parse_ctx_t x;
                s_sensor_t *p_sensor = NULL;
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    if (g_floor_list->floors[i].id != floor_id) {
                        continue;
                    }
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor";
                    // err =
                    parse_xml(&x);
                    num_sensors = x.num_results;
                    if (!(p_sensor = (s_sensor_t *)calloc(num_sensors, sizeof(s_sensor_t))))
                    {
                        log_printf(LOG_CRIT,
                                   "In %s: can't allocate memory for sensors!\n", __func__);
                        exit(EXIT_FAILURE);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the id of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/id";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].id = atoi(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);
    
                    // Get the name of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/name";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        memcpy(p_sensor[k].name, x.results[k],
                               strlen(x.results[k]));
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the base energy of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/baseEnergy";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].base_energy = atof(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the used energy of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/energy";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].used_energy = atof(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the saved energy of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/savedEnergy";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].saved_energy = atof(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the occupancy savings of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/occSavings";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].occ_saved_energy = atof(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the ambient savings of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/ambientSavings";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].amb_saved_energy = atof(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the task tuned savings of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/tuneupSavings";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].task_saved_energy = atof(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the manual savings of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/manualSavings";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].manual_saved_energy = atof(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the occupancy of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/occupancy";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].occupancy = atoi(x.results[k]);
                        if (p_sensor[k].occupancy > 1)
                        {
                            log_printf(LOG_ERR,
                                       "Seeing occupancy of %d for sensor %s",
                                       p_sensor[k].occupancy, p_sensor[k].name);
                        }
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the dim level of sensor
                    x.xml_buf = xml;
                    x.xml_xpath = "sensorEnergyStatss/sensorEnergyStats/sensor/dimLevel";
                    // err =
                    parse_xml(&x);
                    for (k = 0; k < num_sensors; k++)
                    {
                        p_sensor[k].dim_level = atoi(x.results[k]);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    qsort((void *)p_sensor, num_sensors, sizeof(s_sensor_t),
                          compare_sensor_id_sort);

                    s_sensor_t *sptr = NULL;
                    for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_sensors; k++)
                        {
                            unsigned int id = g_floor_list->floors[i].s_area[j].s_sensor[k].id;
                            if ((sptr = bsearch(&id, p_sensor, num_sensors,
                                                sizeof(s_sensor_t),
                                                compare_sensor_id_search)) != NULL)
                            {
                                // Found sensor id.
                                // Copy the energy data.
                                // Mark state as valid.
                                memcpy(&g_floor_list->floors[i].s_area[j].s_sensor[k].base_energy, &sptr->base_energy, sizeof(s_sensor_t) - offsetof(s_sensor_t, base_energy));
                            }
                        }
                    }
                    free(p_sensor);
                }
            }
        }
        else
        {
            log_printf(LOG_CRIT, "In %s: can't stat file %s\n",
                        __func__, ofile);
            exit(EXIT_FAILURE);
        }
        fclose(fp);
    }
    else
    {
        log_printf(LOG_CRIT, "In %s: can't open file %s\n", __func__, ofile);
        exit(EXIT_FAILURE);
    }

    return 0;
}
#endif

#ifdef EM
static int get_sensors_location_per_area_per_floor(int area_id, int floor_id)
{
    // int   rc = 0;
    char  url[1024];
    char  ofile[256];
  
    snprintf(url, sizeof(url), GET_SENSORS_LOC_BY_AREA_API,
             elf_get_db_gems_ip_address_config(), area_id, floor_id);
    snprintf(ofile, sizeof(ofile), "%s/%s_%d_%d.%s", TMP_FILES_PATH,
             SENSORS_LOC_XML, floor_id, area_id, TMP_FILE_PREFIX);

    // rc =
    send_curl_message(REQ_TYPE_GET, url, true, NULL, ofile);

    FILE *fp = fopen(ofile, "r");
    if (fp)
    {
        char        *xml = NULL;
        struct stat  st;
        if (!stat(ofile, &st))  
        {
            if (st.st_size != 0)
            {
                xml = calloc(1, st.st_size+1); // +1 for null termination
                if (!xml)
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for xml data!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }

                int count = 0;
                while (!feof(fp))
                {
                    count += fread(xml+count, 1, 1, fp);
                }

                // int err,
                int i, j;
                xml_parse_ctx_t x;
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        if (!((g_floor_list->floors[i].id == floor_id) &&
                             (g_floor_list->floors[i].s_area[j].id == area_id)))
                        {
                            continue;
                        }
                        x.xml_buf = xml;
                        x.xml_xpath = "fixtures/fixture";
                        // err =
                        parse_xml(&x);
                        g_floor_list->floors[i].s_area[j].num_sensors = x.num_results;
                        if (!(g_floor_list->floors[i].s_area[j].s_sensor = (s_sensor_t *)calloc(g_floor_list->floors[i].s_area[j].num_sensors, sizeof(s_sensor_t))))
                        {
                            log_printf(LOG_CRIT,
                                       "In %s: can't allocate memory for sensors!\n", __func__);
                            exit(EXIT_FAILURE);
                        }
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);

                        // Get the id of sensor
                        x.xml_buf = xml;
                        x.xml_xpath = "fixtures/fixture/id";
                        // err =
                        parse_xml(&x);
                        int k;
                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_sensors; k++)
                        {
                            g_floor_list->floors[i].s_area[j].s_sensor[k].id = atoi(x.results[k]);
                        }
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);
    
                        // Get the name of sensor
                        x.xml_buf = xml;
                        x.xml_xpath = "fixtures/fixture/name";
                        // err =
                        parse_xml(&x);
                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_sensors; k++)
                        {
                            memcpy(g_floor_list->floors[i].s_area[j].s_sensor[k].name, x.results[k], strlen(x.results[k]));
                        }
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);

                        // Get the xaxis of sensor
                        x.xml_buf = xml;
                        x.xml_xpath = "fixtures/fixture/xaxis";
                        // err =
                        parse_xml(&x);
                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_sensors; k++)
                        {
                            g_floor_list->floors[i].s_area[j].s_sensor[k].x = atoi(x.results[k]);
                        }
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);

                        // Get the yaxis of sensor
                        x.xml_buf = xml;
                        x.xml_xpath = "fixtures/fixture/yaxis";
                        // err =
                        parse_xml(&x);
                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_sensors; k++)
                        {
                            g_floor_list->floors[i].s_area[j].s_sensor[k].y = atoi(x.results[k]);
                        }
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);

                        // Get the mac-address of sensor
                        x.xml_buf = xml;
                        x.xml_xpath = "fixtures/fixture/macaddress";
                        // err =
                        parse_xml(&x);
                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_sensors; k++)
                        {
                            sscanf(x.results[k], "%hhx:%hhx:%hhx",
                                   &g_floor_list->floors[i].s_area[j].s_sensor[k].mac_address[0], &g_floor_list->floors[i].s_area[j].s_sensor[k].mac_address[1], &g_floor_list->floors[i].s_area[j].s_sensor[k].mac_address[2]);
                        }
                        free(x.results);
                        roxml_release(RELEASE_ALL);
                        roxml_close(x.root);

                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_sensors; k++)
                        {
                           g_floor_list->floors[i].s_area[j].s_sensor[k].state = DEVICE_STATE_INIT;
                        }

                        qsort((void *)g_floor_list->floors[i].s_area[j].s_sensor, g_floor_list->floors[i].s_area[j].num_sensors, sizeof(s_sensor_t), compare_sensor_id_sort);
                        // Get historical sensor data for the current time period
                        get_sensors_energy_stats_per_floor(g_floor_list->floors[i].id);
                        // Get the average values per area
                        s_sensor_t *p_sensor = (s_sensor_t *)g_floor_list->floors[i].s_area[j].s_sensor;
                        s_area_t *p_area = (s_area_t *)&g_floor_list->floors[i].s_area[j];
                        p_area->base_energy = 0;
                        p_area->used_energy = 0;
                        p_area->saved_energy = 0;
                        p_area->occ_saved_energy = 0;
                        p_area->amb_saved_energy = 0;
                        p_area->task_saved_energy = 0;
                        p_area->manual_saved_energy = 0;
                        p_area->avg_dim_level = 0;

                        uint16_t num_sensors = p_area->num_sensors;
                        float    value = 0.0;

                        log_printf(LOG_INFO, "Area=%s", p_area->name);
                        // cumulative base energy
                        for (value = 0, k = 0; k < num_sensors; k++)
                        {
                            value += p_sensor[k].base_energy;
                        }
                        p_area->base_energy = value;
                        log_printf(LOG_INFO, "BE=%f", p_area->base_energy);

                        // cumulative used energy
                        for (value = 0, k = 0; k < num_sensors; k++)
                        {
                            value += p_sensor[k].used_energy;
                        }
                        p_area->used_energy = value;
                        log_printf(LOG_INFO, "UE=%f", p_area->used_energy);

                        // cumulative saved energy
                        for (value = 0, k = 0; k < num_sensors; k++)
                        {
                            value += p_sensor[k].saved_energy;
                        }
                        p_area->saved_energy = value;
                        log_printf(LOG_INFO, "SE=%f", p_area->saved_energy);

                        // cumulative occupancy saved energy
                        for (value = 0, k = 0; k < num_sensors; k++)
                        {
                            value += p_sensor[k].occ_saved_energy;
                        }
                        p_area->occ_saved_energy = value;
                        log_printf(LOG_INFO, "OSE=%f", p_area->occ_saved_energy);

                        // cumulative ambient saved energy
                        for (value = 0, k = 0; k < num_sensors; k++)
                        {
                            value += p_sensor[k].amb_saved_energy;
                        }
                        p_area->amb_saved_energy = value;
                        log_printf(LOG_INFO, "ASE=%f", p_area->amb_saved_energy);

                        // cumulative task saved energy
                        for (value = 0, k = 0; k < num_sensors; k++)
                        {
                            value += p_sensor[k].task_saved_energy;
                        }
                        p_area->task_saved_energy = value;
                        log_printf(LOG_INFO, "TSE=%f", p_area->task_saved_energy);

                        // cumulative manual saved energy
                        for (value = 0, k = 0; k < num_sensors; k++)
                        {
                            value += p_sensor[k].manual_saved_energy;
                        }
                        p_area->manual_saved_energy = value;
                        log_printf(LOG_INFO, "MSE=%f", p_area->manual_saved_energy);

                        // average dim level
                        uint32_t dim_level = 0;
                        for (dim_level = 0, k = 0; k < num_sensors; k++)
                        {
                            dim_level += p_sensor[k].dim_level;
                        }
                        if (num_sensors) {
                            p_area->avg_dim_level = (dim_level/num_sensors);
                        }
                        log_printf(LOG_INFO, "DL=%d", p_area->avg_dim_level);

#ifdef EM
                        // occupancy for the area
                        uint8_t occupancy = 0;
#if 0
                        for (k = 0; k < num_sensors; k++)
                        {
                            if ((occupancy = p_sensor[k].occupancy))
                            {
                                // any sensor sees occupancy break.
                                break;
                            }
                        }
#else
                        snprintf(url, sizeof(url), GET_FLOOR_AREA_OCC_STATE_API,
                                 elf_get_db_gems_ip_address_config(), floor_id);
                        snprintf(ofile, sizeof(ofile), "%s/%s_%d.%s",
                                 TMP_FILES_PATH, GET_FLOOR_AREA_OCC_XML,
                                 floor_id, TMP_FILE_PREFIX);

                        // rc =
                        send_curl_message(REQ_TYPE_GET, url, true, NULL,
                                               ofile);
                        FILE *fp = fopen(ofile, "r");
                        if (fp)
                        {
                            char        *xml = NULL;
                            struct stat  st;
                            if (!stat(ofile, &st))  
                            {
                                if (st.st_size != 0)
                                {
                                    xml = calloc(1, st.st_size+1); // +1 for null termination
                                    if (!xml)
                                    {
                                        log_printf(LOG_CRIT,
                                                   "In %s: can't allocate memory for xml data!\n",
                                                   __func__);
                                        exit(EXIT_FAILURE);
                                    }

                                    count = 0;
                                    while (!feof(fp))
                                    {
                                        count += fread(xml+count, 1, 1, fp);
                                    }

                                    // Get number of areas
                                    int num_areas, area_idx = -1;
                                    x.xml_buf = xml;
                                    x.xml_xpath = "areas/area";
                                    // err =
                                    parse_xml(&x);
                                    num_areas = x.num_results;

                                    // Free allocated buffer
                                    free(x.results);
                                    roxml_release(RELEASE_ALL);
                                    roxml_close(x.root);

                                    // Get the id of area
                                    x.xml_buf = xml;
                                    x.xml_xpath = "areas/area/id";
                                    // err =
                                    parse_xml(&x);
                                    for (k = 0; k < num_areas; k++)
                                    {
                                        if (area_id == atoi(x.results[k]))
                                        {
                                            // Found area we are interested in.
                                            area_idx = k;
                                            break;
                                        }
                                    }
                                    free(x.results);
                                    roxml_release(RELEASE_ALL);
                                    roxml_close(x.root);
                
                                    // Get the occupancy of area
                                    x.xml_buf = xml;
                                    x.xml_xpath = "areas/area/occupancyState";
                                    // err =
                                    parse_xml(&x);

                                    // Get occupancy state for the area
                                    if (area_idx >= 0) {
                                        occupancy = atoi(x.results[area_idx]);
                                    }
                                    else {
                                        occupancy = 0;
                                    }

                                    free(x.results);
                                    roxml_release(RELEASE_ALL);
                                    roxml_close(x.root);
                
                                }
                            }
                        }
#endif
                        p_area->occupancy = occupancy;
                        log_printf(LOG_INFO, "OCC=%d", p_area->occupancy);
#endif // EM

                        // update object instance ids
                        g_floor_list->floors[i].s_area[j].num_obj_types = MAX_OBJECT_TYPES;
                        if (!(g_floor_list->floors[i].s_area[j].s_oid = (s_oid_t *)calloc(g_floor_list->floors[i].s_area[j].num_obj_types, sizeof(s_oid_t))))
                        {
                            log_printf(LOG_CRIT,
                                       "In %s: can't allocate memory for object instance ids!\n", __func__);
                            exit(EXIT_FAILURE);
                        }

                        for (k = 0; k < g_floor_list->floors[i].s_area[j].num_obj_types; k++)
                        {
                            int num_objs = elf_get_number_of_objects(SENSOR_OBJECT_TYPE, obj_types[k]);
                            int num_sensors = g_floor_list->floors[i].s_area[j].num_sensors;
                            g_floor_list->floors[i].s_area[j].s_oid[k].type = obj_types[k];
                            g_floor_list->floors[i].s_area[j].s_oid[k].num_oids = (num_objs*num_sensors);
                            if (!(g_floor_list->floors[i].s_area[j].s_oid[k].oid = (unsigned int *)calloc(g_floor_list->floors[i].s_area[j].s_oid[k].num_oids, sizeof(unsigned int))))
                            {
                                log_printf(LOG_CRIT,
                                           "In %s: can't allocate memory for oids!\n", __func__);
                                exit(EXIT_FAILURE);
                            }
                            int l;
                            for (l = 0; l < num_objs; l++)
                            {
                                if (!elf_is_object_index_valid(SENSOR_OBJECT_TYPE, obj_types[k], l+STARTING_SENSORS_OBJECT_INDEX))
                                {
                                    continue;
                                }
                                int m;
                                for (m = 0; m < num_sensors; m++)
                                {
                                    g_floor_list->floors[i].s_area[j].s_oid[k].oid[m*num_objs+l] = SET_OBJECT_INSTANCE(g_floor_list->floors[i].s_area[j].s_sensor[m].id,l+STARTING_SENSORS_OBJECT_INDEX);
                                }
                            }
                        }
                    }
                }
            }
        }
        else
        {
            log_printf(LOG_CRIT, "In %s: can't stat file %s\n",
                       __func__, ofile);
            exit(EXIT_FAILURE);
        }
        fclose(fp);
    }
    else
    {
        log_printf(LOG_CRIT, "In %s: can't open file %s\n", __func__, ofile);
        exit(EXIT_FAILURE);
    }

    return 0;
}
#endif

static int get_areas_per_floor(int floor_id)
{
    // int   rc = 0;
    char  url[1024];
    char  ofile[256];
  
    snprintf(url, sizeof(url), GET_AREA_LIST_API,
             elf_get_db_gems_ip_address_config(), floor_id);
    snprintf(ofile, sizeof(ofile), "%s/%s_%d.%s", TMP_FILES_PATH,
             AREAS_XML, floor_id, TMP_FILE_PREFIX);

    // rc =
    send_curl_message(REQ_TYPE_GET, url, true, NULL, ofile);

    FILE *fp = fopen(ofile, "r");
    if (fp)
    {
        char        *xml = NULL;
        struct stat  st;
        if (!stat(ofile, &st))
        {
            if (st.st_size != 0)
            {
                xml = calloc(1, st.st_size+1); // +1 for null termination
                if (!xml)
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for xml data!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }

                int count = 0;
                while (!feof(fp))
                {
                    count += fread(xml+count, 1, 1, fp);
                }

                // int err,
                int i;
                xml_parse_ctx_t x;
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    if (g_floor_list->floors[i].id != floor_id) {
                        continue;
                    }
                    g_floor_list->floors[i].num_areas = 0;
                    x.xml_buf = xml;
#ifdef UEM
                    x.xml_xpath = "zones/zone";
                    // err =
                    parse_xml(&x);
                    g_floor_list->floors[i].num_areas = x.num_results;
#else
                    x.xml_xpath = "areas/area";
                    // err =
                    parse_xml(&x);
                    // +1 for unassigned area.
                    g_floor_list->floors[i].num_areas = x.num_results + 1;
#endif
                    if (!(g_floor_list->floors[i].s_area = (s_area_t *)calloc(g_floor_list->floors[i].num_areas, sizeof(s_area_t))))
                    {
                        log_printf(LOG_CRIT,
                                   "In %s: can't allocate memory for areas!\n",
                                   __func__);
                        exit(EXIT_FAILURE);
                    }
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    // Get the id of area
                    x.xml_buf = xml;
#ifdef UEM
                    x.xml_xpath = "zones/zone/id";
                    // err =
                    parse_xml(&x);
                    int j;
                    for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        g_floor_list->floors[i].s_area[j].id = atoi(x.results[j]);
                    }
#else
                    // Setup for unassigned area.
                    // unassigned area has id of 0.
                    g_floor_list->floors[i].s_area[0].id = 0;
                    strcpy((char *)g_floor_list->floors[i].s_area[0].name,
                           "Unassigned");
                    //g_floor_list->floors[i].s_area[0].type = LTG_ZONE_DEVICE_TYPE;
                    g_floor_list->floors[i].s_area[0].type = SENSOR_OBJECT_TYPE;
                    g_floor_list->floors[i].s_area[0].state = DEVICE_STATE_VALID;

                    // Get info for remaining areas if any
                    x.xml_xpath = "areas/area/id";
                    // err =
                    parse_xml(&x);
                    int j;
                    for (j = 1; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        g_floor_list->floors[i].s_area[j].id = atoi(x.results[j-1]);
                    }
#endif
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);
    
                    // Get the name of area
                    x.xml_buf = xml;
#ifdef UEM
                    x.xml_xpath = "zones/zone/name";
                    // err =
                    parse_xml(&x);
                    for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        memcpy(g_floor_list->floors[i].s_area[j].name,
                               x.results[j], strlen(x.results[j]));
                    }
#else
                    x.xml_xpath = "areas/area/name";
                    // err =
                    parse_xml(&x);
                    for (j = 1; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        memcpy(g_floor_list->floors[i].s_area[j].name,
                               x.results[j-1], strlen(x.results[j-1]));
                    }
#endif
                    free(x.results);
                    roxml_release(RELEASE_ALL);
                    roxml_close(x.root);

                    for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        //g_floor_list->floors[i].s_area[j].type = LTG_ZONE_DEVICE_TYPE;
                        g_floor_list->floors[i].s_area[j].type = SENSOR_OBJECT_TYPE;
                    }

                    for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
                    {
                        g_floor_list->floors[i].s_area[j].state = DEVICE_STATE_VALID;
#ifdef UEM
                        get_hvac_stats_per_zone(g_floor_list->floors[i].s_area[j].id);
#else
                        get_sensors_location_per_area_per_floor(g_floor_list->floors[i].s_area[j].id, g_floor_list->floors[i].id);
#endif
                    }
                    printf("\n");
                }
                free(xml);
            }
        }
        else
        {
            log_printf(LOG_CRIT, "In %s: can't stat file %s\n",
                       __func__, ofile);
            exit(EXIT_FAILURE);
        }
        fclose(fp);
    }
    else
    {
        log_printf(LOG_CRIT, "In %s: can't open file %s\n", __func__, ofile);
        exit(EXIT_FAILURE);
    }

    return 0;
}

int sync_data_from_em(void)
{
    // int  rc = 0;
    char url[1024];
    char ofile[256];
  
    if (g_floor_list)
    {
        int i, j;
        for (i = 0; i < g_floor_list->num_floors; i++)
        {
            for (j = 0; j < g_floor_list->floors[i].num_areas; j++)
            {
#ifdef EM
                free(g_floor_list->floors[i].s_area[j].s_sensor);
#endif
                int k;
                for (k = 0; k < g_floor_list->floors[i].s_area[j].num_obj_types; k++)
                {
                    free(g_floor_list->floors[i].s_area[j].s_oid[k].oid);
                }
                free(g_floor_list->floors[i].s_area[j].s_oid);
            }
            free(g_floor_list->floors[i].s_area);
        }
        free(g_floor_list->floors);
        free(g_floor_list);
        g_floor_list = NULL;
    }

    snprintf(url, sizeof(url), GET_FLOOR_LIST_API,
             elf_get_db_gems_ip_address_config());
    snprintf(ofile, sizeof(ofile), "%s/%s.%s", TMP_FILES_PATH,
             FLOORS_XML, TMP_FILE_PREFIX);
    unlink(ofile);
    // rc =
    send_curl_message(REQ_TYPE_GET, url, true, NULL, ofile);

    FILE *fp = fopen(ofile, "r");
    if (fp)
    {
        char        *xml = NULL;
        struct stat  st;
        if (!stat("/tmp/floors.xml", &st))  
        {
            if (st.st_size != 0)
            {
                xml = calloc(1, st.st_size+1); // +1 for null termination
                if (!xml)
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for xml data!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }

                int count = 0;
                while (!feof(fp))
                {
                    count += fread(xml+count, 1, 1, fp);
                }

                // At this point all the data from the file has been read.
                // we can now parse the xml and get the list of floors.
                // int err,
                int i;
                xml_parse_ctx_t x;


                // Get the list of floors.
                x.xml_buf = xml;
                x.xml_xpath = "floors/floor";
                // err =
                parse_xml(&x);

                if (!(g_floor_list = (s_floor_list_t *)calloc(1, sizeof(s_floor_list_t))))
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for floor list!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }
                g_floor_list->num_floors = x.num_results;

                if (!(g_floor_list->floors = (s_floor_t *)calloc(g_floor_list->num_floors, sizeof(s_floor_t))))
                {
                    log_printf(LOG_CRIT,
                               "In %s: can't allocate memory for floors!\n",
                               __func__);
                    exit(EXIT_FAILURE);
                }
                free(x.results);
                roxml_release(RELEASE_ALL);
                roxml_close(x.root);

                // Get the id of floors
                x.xml_buf = xml;
                x.xml_xpath = "floors/floor/id";
                // err =
                parse_xml(&x);
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    g_floor_list->floors[i].id = atoi(x.results[i]);
                }
                free(x.results);
                roxml_release(RELEASE_ALL);
                roxml_close(x.root);

                // Get the name of floors
                x.xml_buf = xml;
                x.xml_xpath = "floors/floor/name";
                // err =
                parse_xml(&x);
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    memcpy(g_floor_list->floors[i].floor_name, x.results[i],
                           strlen(x.results[i]));
                }
                free(x.results);
                roxml_release(RELEASE_ALL);
                roxml_close(x.root);

                // Get the building name of floors
                x.xml_buf = xml;
                x.xml_xpath = "floors/floor/buildingName";
                // err =
                parse_xml(&x);
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    memcpy(g_floor_list->floors[i].bldg_name, x.results[i],
                           strlen(x.results[i]));
                }
                free(x.results);
                roxml_release(RELEASE_ALL);
                roxml_close(x.root);

                // Get the campus name of floors
                x.xml_buf = xml;
                x.xml_xpath = "floors/floor/campusName";
                // err =
                parse_xml(&x);
                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    memcpy(g_floor_list->floors[i].campus_name, x.results[i],
                           strlen(x.results[i]));
                }
                free(x.results);
                roxml_release(RELEASE_ALL);
                roxml_close(x.root);

                // Get the Company name of floors
                x.xml_buf = xml;
#ifdef UEM
                // todo, confirm this difference in APIs is deliberate/will persist...
                x.xml_xpath = "floors/floor/companyName";
#else
                x.xml_xpath = "floors/floor/organization";
#endif
                // err =
                parse_xml(&x);
                // todo, consider this same safety check on all of the above... just a typo/change in the xml can cause gpf. A warning here may save some
                // future debugger hours
                if ( x.num_results == g_floor_list->num_floors )
                {
                	for (i =  0; i < g_floor_list->num_floors; i++)
                	{
                		memcpy(g_floor_list->floors[i].company_name, x.results[i],
                				strlen(x.results[i]));
                	}
                }
                free(x.results);
                roxml_release(RELEASE_ALL);
                roxml_close(x.root);
                free(xml);

                for (i = 0; i < g_floor_list->num_floors; i++)
                {
                    get_areas_per_floor(g_floor_list->floors[i].id);
                }
            }
        }
        else
        {
            log_printf(LOG_CRIT, "In %s: can't stat file %s\n",
                       __func__, ofile);
            exit(EXIT_FAILURE);
        }
        fclose(fp);
    }
    else
    {
        log_printf(LOG_CRIT, "In %s: can't open file %s\n", __func__, ofile);
        exit(EXIT_FAILURE);
    }

    return 0;
}
