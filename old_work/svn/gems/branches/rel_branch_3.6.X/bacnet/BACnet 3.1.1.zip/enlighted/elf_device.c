#include "elf.h"
#include "elf_gems_api.h"

void elf_get_device_mac_address(uint8_t *mac_address)
{
    BACNET_ADDRESS address;

    routed_get_my_address(&address);

    if (mac_address) {
        memcpy(mac_address, &address.adr, 6);
    }
}

const char *elf_get_device_object_name(char *name, int name_len)
{
    uint32_t id = elf_get_device_id();
    s_zone_t *ptr = (s_zone_t *)get_zone_data(id);
    if (ptr)
    {
        // Found zone
        const char *fmt = (const char *)elf_get_device_name_format_string();
        int use_default = 1;

        unsigned char name_fmt[512];
        if (fmt)
        {
            char *nptr = (char *)fmt;
            unsigned int i = 0, j = 0;
            memset(name_fmt, 0, sizeof(name_fmt));
            while ((*nptr) && (i < (sizeof(name_fmt)-1)))
            {
                switch (*nptr)
                {
                    case '%':
                    {
                        switch (*(nptr+1))
                        {
                            case 'C':
                            {
                                for (j = 0; (j < strlen((char *)ptr->company_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = ptr->company_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'c':
                            {
                                for (j = 0; (j < strlen((char *)ptr->campus_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = ptr->campus_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'B':
                            {
                                for (j = 0; (j < strlen((char *)ptr->bldg_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = ptr->bldg_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'F':
                            {
                                for (j = 0; (j < strlen((char *)ptr->floor_name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = ptr->floor_name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'Z':
                            {
                                for (j = 0; (j < strlen((char *)ptr->name) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = ptr->name[j];
                                }
                                nptr += 2;
                                break;
                            }
                            case 'T':
                            {
#ifdef UEM
                            	// todo - pick this from the config file rather...
                                char *t = "HVAC";
#else
                                char *t = "LTG";
#endif
                                for (j = 0; (j < strlen((char *)t) && (i < (sizeof(name_fmt)-1))); j++)
                                {
                                    name_fmt[i++] = t[j];
                                }
                                nptr += 2;
                                break;
                            }
                            default:
                            {
                                name_fmt[i++] = *nptr++;
                                break;
                            }
                        }
                        break;
                    }
                    default:
                    {
                        name_fmt[i++] = *nptr++;
                        break;
                    }
                }
            }
        }

        if (use_default)
        {
#ifdef UEM
        	// todo, why are we doing this twice?
            snprintf(name, name_len, DEFAULT_DEVICE_NAME_FMT_STR,
                     ptr->company_name, ptr->campus_name, ptr->bldg_name,
                     ptr->floor_name, ptr->name, "HVAC");
#else
            snprintf(name, name_len, DEFAULT_DEVICE_NAME_FMT_STR,
                     ptr->company_name, ptr->campus_name, ptr->bldg_name,
                     ptr->floor_name, ptr->name, "LTG");
#endif
        }
        else {
            strcpy((char *)name, (char *)name_fmt);
        }
        free(ptr);
    }
    else
    {
    	BACNET_CHARACTER_STRING ourName ;
    	Routed_Device_Name(id, &ourName ) ;
        snprintf(name, name_len, "%s", ourName.value );
    }
    log_printf(LOG_INFO, "Device name = %s", name);

    return name;
}

const char *elf_get_device_app_sw_version(char *name, int name_len)
{
    snprintf(name, name_len, "%s", "0.0.0");
    return name;
}

int elf_set_device_system_status(void)
{
    // int                   rc = 0;
    BACNET_DEVICE_STATUS  system_status = STATUS_OPERATIONAL;

    uint32_t id = elf_get_device_id();
    s_zone_t *ptr = (s_zone_t *)get_zone_data(id);
    if (ptr)
    {
        // Found zone
        if (ptr->state != DEVICE_STATE_VALID) {
            system_status = STATUS_NON_OPERATIONAL;
        }
        free(ptr);
    }
    else {
        system_status = STATUS_NON_OPERATIONAL;
    }
    // rc =
    Device_Set_System_Status(system_status, 1);
    return 0;
}

