#ifndef __ELF_STD_H__
#define __ELF_STD_H__

#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <memory.h>
#include <string.h>
#include <sys/select.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <time.h>
#include <termios.h>
#include <signal.h>

#include "bacenum.h"
#include "device.h"

typedef unsigned char NODE_ADDRESS[3];

#if ! defined ( UEM ) && ! defined ( EM )
// #define UEM		// Define one just in case. (Default)
#error Choose one or the other via Makefile, not both. UEM=HVAC, EM=Lighting
#endif


// for intellitrace in Eclipse
#ifndef ENLIGHTED_INC
#define ENLIGHTED_INC
#endif

#endif /* __ELF_STD_H__ */
