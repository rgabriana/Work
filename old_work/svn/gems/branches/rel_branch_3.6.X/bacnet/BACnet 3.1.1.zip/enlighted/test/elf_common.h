#ifndef __ELF_COMMON_H__
#define __ELF_COMMON_H__

typedef unsigned char NODE_ADDRESS[3];

#endif /* __ELF_COMMON_H__ */
