#ifndef _ELF_XML_PARSE_H_
#define _ELF_XML_PARSE_H_

#include <roxml.h>

typedef struct xml_parse_ctx
{
	node_t *root;
	// inputs
	char *xml_buf;
	char *xml_xpath;
	// outputs
	int num_results;
	char **results;
} xml_parse_ctx_t;

int parse_xml(xml_parse_ctx_t *x);

#endif
