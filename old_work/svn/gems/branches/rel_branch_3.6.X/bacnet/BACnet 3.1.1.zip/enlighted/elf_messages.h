#ifndef __ELF_MESSAGES_H__
#define __ELF_MESSAGES_H__

#include "elf_std.h"

// For GEMS communication
#define GEMS_RX_DATA_LEN     (128)
#define GEMS_RX_PORT         (51367)
#define MY_RX_PORT           (51368)
#define LOCALHOST            ("127.0.0.1")
//#define LOCALHOST            ("10.8.3.126")

#define SOFTWARE_VERSION_LEN (16)

typedef enum
{
    REQ_CMD = 1,
    RSP_CMD
} eMessage_types_t;

typedef enum
{
    NOT_PRESENT = 0,
    DISCOVERED,
    COMMISSIONED,
    DELETED,
    COMM_FAILURE,
    SWITCHED_OFF,
} eDevice_State_t;

typedef enum
{
/* 1 */   DISCOVER_SENSOR = 1, // Get data for all sensors
/* 2 */   GET_SENSOR_DATA, // Not implemented
/* 3 */   GET_SENSOR_DATA_BY_ID, // Get data for given sensor id
/* 4 */   SET_SENSOR_DIM, // Not implemented
/* 5 */   SET_SENSOR_DIM_BY_ID, // Dim sensor for given id
/* 6 */   DISCOVER_GW, // Get data of all gateways
/* 7 */   DISCOVER_SENSOR_BY_GW_ID, // Get data of all sensors for a gateway
/* 8 */   GET_SENSOR_DATA_BY_GW_ID, // Get data for all sensors for gateway id
/* 9 */   GET_GATEWAY_DATA_BY_ID, // Get data for gateway for id
/* A */   GET_SENSOR_LOC_DATA_BY_ID, // Get location data for given sensor id
/* B */   SET_SENSOR_PROFILE_ID_BY_ID, // Set Sensor Profile Id
/* C */   SET_LIGHT_LEVEL_BY_PROFILE_ID, // Set Light Level by Profile Id

/* 0x61 */ DISCOVER_ZONES = 0x61,
/* 0x62 */ GET_ZONE_DATA_BY_ID,
/* 0x63 */ GET_ZONE_STATUS_BY_ID,
/* 0x64 */ SET_BMS_STATUS,
/* 0x65 */ SET_ZONE_DIM_LEVEL,

    /* GEMS messages start from here */
/* 0x81 */ GET_GEMS_DATA = 0x81,
/* 0x82 */ SET_GEMS_DR_CONFIG,
/* 0x83 */ GET_GEMS_DR_STATUS,
/* 0x61 */ ENABLE_GEMS_DR,
} eMesssages_t;

typedef struct message_header
{
    uint8_t  type;
    uint8_t  ver;
    uint16_t len;
    uint32_t txid;   
    uint8_t  cmd;
    union
    {
        uint8_t  result; // this is used in response message
        uint8_t  flags;  // this is used in request message
    } u;
    uint16_t rsvd;
} __attribute__ ((__packed__)) message_hdr_t;

typedef struct
{
    uint32_t     id;
    NODE_ADDRESS address;
    uint8_t      state;
} __attribute__ ((__packed__)) gems_device_t;

/* Sensor messages start from here. */

/* Discover message. This message is used to discover gateways and sensors. */
typedef struct
{
    message_hdr_t hdr;
} __attribute__ ((__packed__)) discover_msg_req_t;

/* Discover message response. Contains data for gateways and sensors. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to gems_device_t
} __attribute__ ((__packed__)) discover_msg_rsp_t;

/* This structure contains sensor data. */
typedef struct
{
    uint32_t      id;
    NODE_ADDRESS  address;
    uint8_t       state;
    uint8_t       version[SOFTWARE_VERSION_LEN]; // null terminated by GEMS
    uint8_t       light_status;
    uint16_t      load;
    uint8_t       occupancy;
    uint16_t      dim;
    int16_t       temperature;
    uint16_t      profile_id;
    uint16_t      ambient_light_level;
} __attribute__ ((__packed__)) sensor_info_t;

typedef struct
{
    uint8_t       result;
    sensor_info_t sinfo;
} __attribute__ ((__packed__)) sensor_data_t;

/* Get Sensor by Id message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint32_t      id[]; // variable list
} __attribute__ ((__packed__)) get_sensor_by_id_msg_req_t;

/* This structure contains sensor location data. */
typedef struct
{
    uint8_t       result;
    uint32_t      id;
    NODE_ADDRESS  address;
    uint8_t       state;
    uint8_t       version[SOFTWARE_VERSION_LEN]; // null terminated by GEMS
    uint8_t       light_status;
    uint16_t      load;
    uint8_t       occupancy;
    uint16_t      dim;
    int16_t       temperature;
    uint16_t      profile_id;
    uint16_t      ambient_light_level;
    uint8_t       lan_data[]; // location, area, name data
} __attribute__ ((__packed__)) sensor_loc_data_t;

/* Get Sensor location by Id message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint32_t      id[]; // variable list
} __attribute__ ((__packed__)) get_sensor_loc_by_id_msg_req_t;

/* Get Sensor location by Id response. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to sensor_loc_data_t
} __attribute__ ((__packed__)) get_sensor_loc_msg_rsp_t;

#if 0
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       address[]; // variable list points to gems_device_t
} __attribute__ ((__packed__)) get_sensor_msg_req_t;
#endif

/* Get Sensor by Id response. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to sensor_data_t
} __attribute__ ((__packed__)) get_sensor_msg_rsp_t;

/* Set sensor dim request. */
typedef struct
{
    union
    {
        uint32_t id;
        NODE_ADDRESS address;
    } u;
    uint8_t type;
    uint16_t value;
} __attribute__ ((__packed__)) set_sensor_dim_req_t;

/* Set sensor dim response. */
typedef struct
{
    uint8_t result;
    union
    {
        uint32_t id;
        NODE_ADDRESS address;
    } u;
} __attribute__ ((__packed__)) set_sensor_dim_rsp_t;

/* Sensor dim request message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to set_sensor_dim_req_t
} __attribute__ ((__packed__)) set_sensor_dim_msg_req_t;

/* Sensor dim response message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to set_sensor_dim_rsp_t
} __attribute__ ((__packed__)) set_sensor_dim_msg_rsp_t;

/* Set sensor profile id request. */
typedef struct
{
    union
    {
        uint32_t id;
        NODE_ADDRESS address;
    } u;
    uint16_t profile_id;
    uint8_t  mode; // 1 for auto, 2 for immediate
} __attribute__ ((__packed__)) set_sensor_profile_id_req_t;

/* Set sensor profile id response. */
typedef struct
{
    uint8_t result;
    union
    {
        uint32_t id;
        NODE_ADDRESS address;
    } u;
} __attribute__ ((__packed__)) set_sensor_profile_id_rsp_t;

/* Set profile id request message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to set_sensor_profile_id_req_t
} __attribute__ ((__packed__)) set_sensor_profile_id_msg_req_t;

/* Set profile id response message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to set_sensor_profile_id_rsp_t
} __attribute__ ((__packed__)) set_sensor_profile_id_msg_rsp_t;

/* Set sensor light level by profile id request. */
typedef struct
{
    uint16_t profile_id;
    uint8_t  type;
    int16_t  value;
    uint32_t duration;
} __attribute__ ((__packed__)) set_sensor_light_level_by_profile_id_req_t;

/* Set sensor light level by profile response. */
typedef struct
{
    uint8_t  result;
    uint16_t profile_id;
} __attribute__ ((__packed__)) set_sensor_light_level_by_profile_id_rsp_t;

/* Set sensor light level by profile request message. */
typedef struct
{
    message_hdr_t                              hdr;
    set_sensor_light_level_by_profile_id_req_t data;
} __attribute__ ((__packed__)) set_sensor_light_level_by_profile_id_msg_req_t;

/* Set sensor light level by profile response message. */
typedef struct
{
    message_hdr_t hdr;
} __attribute__ ((__packed__)) set_sensor_light_level_by_profile_id_msg_rsp_t;

/* Gateway messages start from here */

/* Gateway data */
typedef struct
{
    uint8_t       result;
    uint32_t      id;
    NODE_ADDRESS  address;
    uint8_t       state;
    uint8_t       version[SOFTWARE_VERSION_LEN]; // null terminated by GEMS
} __attribute__ ((__packed__)) gateway_data_t;

/* Get Gateway data by Id message request. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint32_t      id[]; // variable list
} __attribute__ ((__packed__)) get_gateway_by_id_msg_req_t;

/* Get Gateway data by Id message response. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_nodes;
    uint8_t       data[]; // variable list points to gateway_data_t
} __attribute__ ((__packed__)) gateway_msg_rsp_t;

/* Discover message is used to discover sensors for given gateway. */
typedef struct
{
    message_hdr_t hdr;
    uint32_t      gw_id;
} __attribute__ ((__packed__)) discover_sensors_per_gateway_msg_req_t;

/* GEMS messages start from here */

/* Get GEMS data message request. */
typedef struct
{
    message_hdr_t hdr;
} __attribute__ ((__packed__)) get_gems_data_msg_req_t;

/* Get GEMS data message response. */
typedef struct
{
    message_hdr_t hdr;
    uint8_t       version[SOFTWARE_VERSION_LEN]; // null terminated by GEMS
} __attribute__ ((__packed__)) get_gems_data_msg_rsp_t;

/* Set DR message request. */
typedef struct
{
    message_hdr_t hdr;
    uint8_t       enable;
    uint16_t      value;
    uint16_t      time; // in minutes that DR is enabled
} __attribute__ ((__packed__)) set_gems_dr_msg_req_t;

/* Set DR message response. */
typedef struct
{
    message_hdr_t hdr;
} __attribute__ ((__packed__)) set_gems_dr_msg_rsp_t;

/* Zone Messages start from here. */
typedef struct
{
    uint16_t num_zones;
} __attribute__ ((__packed__)) discover_zones_msg_rsp_v2_t;

typedef struct
{
    uint32_t  id;
    uint8_t   state;
} __attribute__ ((__packed__)) zone_device_t;

/* Zone List message. This message is used to discover HVAC zones. */
typedef struct
{
    message_hdr_t hdr;
} __attribute__ ((__packed__)) discover_zones_msg_req_t;

/* Zone list message response. Contains list of HVAC zone ids. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_zones;
    uint8_t       data[]; // variable list points to zone_device_t
} __attribute__ ((__packed__)) discover_zones_msg_rsp_t;

/* This structure contains zone data. */
typedef struct
{
    uint32_t      id;
    uint8_t       state;
    uint8_t       lan_data[]; // name, location
} __attribute__ ((__packed__)) zone_info_t;

typedef struct
{
    uint8_t     result;
    zone_info_t info;
} __attribute__ ((__packed__)) zone_data_t;

/* Get Zone data by Id message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_zones;
    uint32_t      id[]; // variable list of zone id's
} __attribute__ ((__packed__)) get_zone_data_by_id_msg_req_t;

/* Get Zone data by Id response. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_zones;
    uint8_t       data[]; // variable list points to zone_data_t
} __attribute__ ((__packed__)) get_zone_data_msg_rsp_t;

/* This structure contains zone data. */
typedef struct
{
    uint32_t  id;
    uint32_t  timestamp;
    uint8_t   occupancy;
    uint8_t   setback;
    uint8_t   fan_speed;
    uint16_t  avg_temp;
    uint16_t  min_temp;
    uint16_t  max_temp;
    uint8_t   heartbeat;
    uint32_t  start_time; // in seconds (0 for now)
    uint32_t  end_time; // in seconds
    uint32_t  client_hb_time; // in seconds
    uint8_t   client_setback;
    uint32_t  energy_consumed; // in watt-hours
    uint8_t   dim_level;
} __attribute__ ((__packed__)) zone_status_info_t;

typedef struct
{
    uint32_t id;
    uint8_t  setback;
    uint16_t avg_temp;
    uint8_t  dim_level;
    uint16_t total_power;
    uint8_t  outage;
} __attribute__ ((__packed__)) zone_status_info_v2_t;

typedef struct
{
    uint8_t            result;
#ifdef USING_WEB_SERVICES
    zone_status_info_v2_t info;
#else
    zone_status_info_t info;
#endif
} __attribute__ ((__packed__)) zone_status_data_t;

/* Get Zone status by Id message. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_zones;
    uint32_t      id[]; // variable list of zone id's
} __attribute__ ((__packed__)) get_zone_status_by_id_msg_req_t;

/* Get Zone status by Id response. */
typedef struct
{
    message_hdr_t hdr;
    uint16_t      num_zones;
    uint8_t       data[]; // variable list points to zone_status_data_t
} __attribute__ ((__packed__)) get_zone_status_msg_rsp_t;

/* Set Zone dim level message. */
typedef struct
{
    message_hdr_t hdr;
    uint32_t      zone_id;
    uint8_t       dim_type;   // absolute or relative
    uint16_t      dim_level;  // Dim level
    uint32_t      dim_time;
} __attribute__ ((__packed__)) set_zone_dim_level_msg_req_t;

/* Set BMS Client status message. */
typedef struct
{
    message_hdr_t hdr;
    uint32_t      zone_id;
    uint8_t       setback;  // BMS Client Setback
} __attribute__ ((__packed__)) set_bms_status_msg_req_t;

/* Set BMS Client status response. */
typedef struct
{
    message_hdr_t hdr;
} __attribute__ ((__packed__)) set_bms_status_msg_rsp_t;

#define MAX_ZONE_NAME_LEN   (256)
/* This structure contains zone data. */
typedef struct ws_zone_device_v2
{
    uint32_t id;
    uint8_t  state;
    uint8_t  name[MAX_ZONE_NAME_LEN]; // name
} __attribute__ ((__packed__)) zone_device_v2_t;

typedef struct
{
    uint16_t        num_zones;
    uint8_t         data[]; // variable list points to ws_zone_device_t
} __attribute__ ((__packed__)) ws_zone_list_t;

#endif /* __ELF_MESSAGES_H__ */
