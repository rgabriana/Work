#include "elf.h"
#include "elf_std.h"
#include "elf_gems_api.h"

extern elf_config_t elf_bacnet_config;

const char *elf_get_av_name(uint32_t object_instance, char *name)
{
    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_VALUE)) {
        return "unknown";
    }
    return elf_get_object_name(OBJECT_ANALOG_VALUE, object_instance, name);
}

const char *elf_get_av_description(uint32_t object_instance)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;
    int8_t            rc = -1;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_VALUE)) {
        return "unknown";
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_VALUE,
    		object_instance,
			// cr00002 not used, taking out for now -- NULL,
			&index);
    if (rc < 0) {
        return "Unknown";
    }

    ptr = elf_get_object_by_type(OBJECT_ANALOG_VALUE, index, OBJECT_CFG_INDEX);
    if (ptr) {
        return ptr->description;
    }

    return "Unknown";
}

BACNET_ENGINEERING_UNITS elf_get_av_units(uint32_t object_instance)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;
    int8_t            rc = -1;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_VALUE)) {
        return 0;
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_VALUE,
    		object_instance,
			// cr00002 not used, taking out for now -- NULL,
			&index);
    if (rc < 0) {
        return 0;
    }

    ptr = elf_get_object_by_type(OBJECT_ANALOG_VALUE, index, OBJECT_CFG_INDEX);
    if (ptr) {
        return ptr->units;
    }

    return 0;
}

float elf_get_av_present_value(uint32_t object_instance)
{
    int       rc = 0;
    uint16_t  index = 0;
    // cr00002 not used, taking out for now -- uint8_t   device_type = 0;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_VALUE)) {
        return 0.0;
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_VALUE,
    		object_instance,
			// cr00002 not used, taking out for now -- &device_type,
			&index);
    if (rc < 0) {
        return 0.0;
    }

    uint8_t  ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   OBJECT_ANALOG_VALUE);
#ifdef EM
    uint8_t  dim_level = 0;
    uint32_t id = elf_get_device_id();
#endif

    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            return 0.0;
        }
    }
#ifdef EM
    else if (elf_bacnet_config.mode == SENSORS_ONLY_MODE)
    {
        dim_level = get_sensor_dim_level(id, object_instance);
    }
    else if ((elf_bacnet_config.mode == ZONE_SENSORS_MODE) ||
             (elf_bacnet_config.mode == ZONE_SENSORS_DIM_ONLY_MODE))
    {
        if (index < ltg_zone_obj_count) {
            return 0.0;
        }
        else
        {
            dim_level = get_sensor_dim_level(id, object_instance);
        }
    }
#endif

#ifdef EM
    switch (index)
    {
        case ELF_AV_DIM_LEVEL_OBJECT:
        {
            rc = dim_level;
            break;
        }
        default:
            break;
    }
#endif

    return rc;
}

int elf_set_av_present_value(uint32_t object_instance, float value)
{
    int       rc = 0;
    uint16_t  index = 0;
    // cr00002 not used, taking out for now -- uint8_t   device_type = 0;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_VALUE)) {
        return 0;
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_VALUE,
    		object_instance,
			// cr00002 not used, taking out for now -- &device_type,
			&index);
    if (rc < 0) {
        return 0;
    }

    uint8_t  ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   OBJECT_ANALOG_VALUE);
    if (index < ltg_zone_obj_count)
    {
        return 0;
    }

    uint32_t id = elf_get_device_id();
    log_printf(LOG_INFO,
               "Writing %f to object instance %d for index %d for device %d",
               value, object_instance, index, id);

    // todo - so AVs are used for by EM, make sure we still support AVs in the device object.
#ifdef EM
    rc = set_sensor_dim_level(id, object_instance, (int)value);
    if (rc < 0) {
        return 0;
    }
#endif

    return rc;
}
