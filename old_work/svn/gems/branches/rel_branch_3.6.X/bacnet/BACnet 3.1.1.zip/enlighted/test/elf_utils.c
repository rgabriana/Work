#include <stdio.h>
#include <stdint.h>
#include <malloc.h>
#include <memory.h>
#include <stdlib.h>

#include "elf_common.h"

typedef struct n2d_map {
    uint32_t     index;
    NODE_ADDRESS address;
} n2d_map_t;

n2d_map_t *n2d_map_table;

int elf_get_node_address_by_index(uint32_t index, NODE_ADDRESS address) {
    if (index >= elf_get_device_count()) {
        printf("index value of %d is gte %d devices\n",
               (int)index, elf_get_device_count());
        return -1;
    }

    if (n2d_map_table) {
        memcpy(address, &n2d_map_table[index].address, sizeof(NODE_ADDRESS));
        return 0;
    }

    return -1;
}

int elf_init_sensors(uint8_t *data) {
    uint32_t   i, j, count = elf_get_device_count();
    uint8_t   *ptr = (uint8_t *)data;

    printf("In %s function\n", __FUNCTION__);

    if (n2d_map_table == NULL) {
        n2d_map_table = (n2d_map_t *)calloc(count, sizeof(n2d_map_t));
        if(n2d_map_table == NULL) {
            exit(1);
        }

        for (i = 0; i < count; i++, ptr += 3) {
            n2d_map_table[i].index = i;
            for (j = 0; j < sizeof(NODE_ADDRESS); j++) {
                n2d_map_table[i].address[j] = (ptr[j] & 0x000000FF);
            }
            printf("Added %02x:%02x:%02x\n", ptr[0], ptr[1], ptr[2]);
        }
    }

    return 0;
}
