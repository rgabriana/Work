#include "elf.h"
#include "elf_gems_api.h"


float   dr_value, dr_time;
uint8_t dr_enabled;

enum profile_bmap
{
    PROFILE_ID = 0,       // 0
    PROFILE_TYPE,         // 1
    PROFILE_VALUE,        // 2
    PROFILE_DURATION,     // 3
    PROFILE_APPLY,        // 4
    // PROFILE_LAST must be the last enum.
    PROFILE_LAST, // this tells how many bits need to be on before applying the
                  // profile.
};

typedef struct elf_su_profile
{
    uint16_t profile_id;
    uint8_t  type;
    int16_t  value;
    uint32_t duration;
    uint16_t bmap; // bitmap represents if all objects are received.
} __attribute__ ((__packed__)) elf_su_profile_t;

elf_su_profile_t g_elf_su_profile_object;
extern elf_config_t elf_bacnet_config;

const char *elf_get_ao_name(uint32_t object_instance, char *name)
{
    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_OUTPUT)) {
        return "Unknown";
    }
    return elf_get_object_name(OBJECT_ANALOG_OUTPUT, object_instance, name);
}

const char *elf_get_ao_description(uint32_t object_instance)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_OUTPUT)) {
        return "Unknown";
    }

    int8_t rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_OUTPUT,
										object_instance,
										// cr00002 not used, taking out for now -- NULL,
										&index);
    if (rc < 0) {
        return "Unknown";
    }

    ptr = elf_get_object_by_type(OBJECT_ANALOG_OUTPUT, index, OBJECT_CFG_INDEX);
    if (ptr) {
        return ptr->description;
    }

    return "Unknown";
}

BACNET_ENGINEERING_UNITS elf_get_ao_units(uint32_t object_instance)
{
    ts_elf_objects_t *ptr = NULL;
    uint16_t          index = 0;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_OUTPUT)) {
        return 0;
    }

    int8_t            rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_OUTPUT,
                                                        object_instance,
														// cr00002 not used, taking out for now -- NULL,
														&index);
    if (rc < 0) {
        return 0;
    }

    ptr = elf_get_object_by_type(OBJECT_ANALOG_OUTPUT, index, OBJECT_CFG_INDEX);
    if (ptr) {
        return ptr->units;
    }

    return 0;
}

int16_t g_profile_id = -1;
float elf_get_ao_present_value(uint32_t object_instance)
{
    int       rc = 0;
    uint16_t  index = 0;
    // cr00002 not used, taking out for now -- uint8_t   device_type = 0;

    if (!is_object_instance_valid(object_instance, OBJECT_ANALOG_OUTPUT)) {
        return 0.0;
    }
    rc = elf_object_instance_to_index(// cr00002 not used, taking out for now -- OBJECT_ANALOG_OUTPUT,
    		object_instance,
			// cr00002 not used, taking out for now -- &device_type,
			&index);
    if (rc < 0) {
        return 0.0;
    }

#ifdef UEM
    float setback ;
#endif

#ifdef UEM

    s_zone_t *zptr;
    uint32_t id = elf_get_device_id();
    uint8_t  ltg_zone_obj_count = 0;

    // Get lighting zone object count
    ltg_zone_obj_count = elf_get_number_of_objects(LTG_ZONE_OBJECT_TYPE,
                                                   OBJECT_ANALOG_OUTPUT);
    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        if ((index >= STARTING_ZONES_OBJECT_INDEX) &&
            (index < ltg_zone_obj_count))
        {
            zptr = (s_zone_t *)get_zone_data(id);
            if (!zptr) {
                return 0.0;
            }
            setback = zptr->setback;
			
			
            free(zptr);
        }
    }
			
			
    switch (index)
    {
        case ELF_AO_ZONE_SETBACK:
            return setback;
	}
			
			
#else
    	// this is the untouched EM case...
#if 0
#ifdef USING_WEB_SERVICES
    if (device_type == LTG_ZONE_DEVICE_TYPE)
    {
#if 0
        uint8_t zone_source;
        switch (index)
        {
            case ELF_HVAC_AO_DIM_LEVEL_OBJECT:
                zone_source = get_zone_dim_level_source(id);
                if (zone_source == ZONE_DATA_SOURCE_EM)
                {
                    rc = get_zone_status_msg(id, &buffer, &data_len);
                    if ( (rc == 0) && buffer)
                    {
                        get_zone_status_msg_rsp_t *p = (get_zone_status_msg_rsp_t *)buffer;
                        zone_status_data_t        *zs = (zone_status_data_t *)p->data;
                        uint8_t dim_level = zs->info.dim_level;
                        free(buffer);
                        return dim_level;
                    }
                }
                else if (zone_source == ZONE_DATA_SOURCE_CACHE)
                {
                    return get_zone_dim_level(id);
                }
                break;
            default:
                break;
        }
#endif
    }
#endif
#endif
#endif /* UEM */

    return 0.0;
}

int elf_set_ao_present_value(ts_elf_objects_t *currentObject, float value)
{
    int       rc = -1;
    // uint16_t  index = 0;
    // cr00002 - uint8_t   device_type = 0;

#ifdef UEM

    uint32_t bacnet_device_instance = elf_get_device_id();

//    s_zone_t *zptr = (s_zone_t *)get_zone_data(id);
//    if (!zptr) {
//        return 0;
//    }
//    uint zid = zptr->id ;
//    free(zptr);

    if (elf_bacnet_config.mode == ZONE_ONLY_MODE)
    {
        set_setback ( bacnet_device_instance, value ) ;
    }


#endif // UEM

    return rc;
}
